LaTeX source for:
"Compute-Aware Safety Certification for Fault-Tolerant Control under
Relative-Degree-One Safety Constraints"
Md Hasibuzzaman, Chan-Yun Yang

Contents
--------
main.tex          - Manuscript source, elsarticle class (Automatica format)
references.bib    - Bibliography source (36 entries)
main.bbl          - Pre-compiled bibliography (fallback; delete and
                    re-run bibtex if references.bib is edited)
figures/          - All figure files (PDF, plus two PNG diagrams)
tables/           - All table .tex fragments, \input by main.tex (13
                    tables, all fitting within the elsarticle text width
                    -- font size reduced via \small/\footnotesize and,
                    for the widest table, shortened header text, as
                    needed per table; each verified visually, not just
                    via the compile log, since table-adjacent paragraphs
                    can trigger false-positive "Overfull hbox" warnings)

Compilation
-----------
Requires the elsarticle document class (texlive-publishers package on
Debian/Ubuntu, or the elsarticle CTAN package). Do not add
\usepackage{natbib} manually -- elsarticle already loads it, and a
duplicate load raises an "Option clash" error. Citation numbering is set
via the [numbers] class option plus \biboptions{sort&compress}. The
default "Preprint submitted to ..." footer is suppressed via
\myfooter[C]{} immediately after \journal{Automatica}.

Compile with:
    pdflatex main.tex
    bibtex main
    pdflatex main.tex
    pdflatex main.tex

Bibliography style is elsarticle-num (numbered, IEEE-like), matching
Automatica's house style.

Notes
-----
- All numerical results in tables and figures were generated from the
  saved experimental logs in the accompanying code/results package.
- Two bibliography entries (greco2008anytime, adapt_quadruped) do not
  include page numbers; not available/verifiable at the original
  source, and not fabricated.
- Declarations (end of manuscript) include Funding/APC-waiver request,
  Declaration of competing interest, Ethical approval, Consent to
  participate/publish, an explicit Open Access statement, and Data
  Availability with the GitHub link.
- Section 3.5.1 quantifies certificate conservatism and Section 3.5.2
  gives its practical interpretation (why an 18-29x gap between
  certified and empirically-required compute does not undermine the
  certificate's design value); Section 5.3 adds adaptive and robust-MPC
  baselines; Section 9.4 gives a decomposed real-time embedded-compute
  benchmark. All backed by results/e11-e13 in the code package.
