Code and experimental results for:
"Linking Computational Budget to Certified Safety Margins for Robot
Fault Tolerant Control"
Md Hasibuzzaman, Chan-Yun Yang

Contents
--------
core/           - Detector (RLS), certificate (confidence radius), CBF-QP
                  filter, multi-actuator filter, unified strategy runner,
                  and baselines_extra.py (adaptive/MIT-rule and
                  robust-MPC FTC baselines).
experiments/    - One script per experiment (e0-e10), each writes its
                  result JSON into results/
testbeds/       - PyBullet adapters: KUKA IIWA manipulator, simple
                  pendulum (from-scratch URDF included), cart-pole
                  (safe-control-gym), Husky wheeled robot
results/        - Saved JSON logs (15 files) plus one .npy trajectory
                  array. Every number in every table and figure in the
                  manuscript is read directly from one of these files;
                  none are invented or estimated.
notes/          - theory.md: full derivation notes, including all
                  propositions, discovered bugs, and revision history.

Latest additions
-----------------
results/e13_certificate_conservatism.json and
results/P_trajectory_representative.npy hold the certified-vs-empirical
compute budget analysis (Table 2, Section 3.5.1 of the manuscript): for
each fault-severity bound, the analytically-certified minimum compute
budget is compared against the empirically-required minimum budget for
near-zero BFTC violations, and against BFTC-binary's violation rate at
that certified budget -- which reveals that the certificate's Phase-1
floor assumes a worst-case margin BFTC-binary does not apply before its
trigger fires. That is the real mechanism behind the conservatism
factor (18-29x), not just its magnitude.

core/baselines_extra.py implements two additional FTC design
philosophies not covered by the original five strategies:

  run_adaptive_ftc()    - classical gradient (MIT-rule) online adaptive
                           control: continuously updates a point estimate
                           of actuator effectiveness and uses it directly
                           in the CBF filter, with NO confidence margin
                           and NO detection trigger. A standard
                           representative of the adaptive-control
                           literature (not a reimplementation of any
                           specific cited paper).
  run_robust_mpc_ftc()  - short receding-horizon (N=5) robust MPC,
                          solved via scipy.optimize SLSQP at every
                          control cycle, using the worst-case fault
                          bound throughout the horizon (no online
                          estimation at all). A standard representative
                          of the robust/MPC FTC literature.

results/e12_extra_baselines.json holds the 80-trial comparison of both
against BFTC at a representative budget (real finding: the adaptive
baseline is genuinely unsafe, 70% violations; robust MPC is safe and
slightly outperforms BFTC on raw performance, at ~5x the measured
per-cycle compute cost).

results/e11_compute_benchmark.json holds a decomposed real-time compute
benchmark (RLS update cost and CBF-QP filter solve cost measured
SEPARATELY, not just aggregated) across m=1,4,8,16, median of 5 repeated
3000-call measurements per cell.

Reproducibility / environment
------------------------------
Python 3.12.3
numpy 2.4.4
scipy 1.17.1
matplotlib 3.10.8
pybullet (API version 202010061)
Hardware: single core, Intel Xeon @ 2.80GHz (confirmed via `lscpu`), 4GB
RAM sandboxed VM. Measured wall-clock cost figures in the manuscript were
produced on this configuration; absolute timings will differ on other
hardware, though relative scaling (O(m) in actuator count, linear in
compute budget) should not.

Random seeds are fixed and stated explicitly in each experiment script;
re-running an experiment script with an unmodified seed will reproduce
the corresponding results/*.json file.

Mapping from manuscript figures/tables to source
-------------------------------------------------
Fig. 1 (concept diagram)        - illustrative, not code-generated
Fig. 2 (theory overview diagram)- illustrative, not code-generated
Fig. 3 (discrete-time verify)   - experiments/e9_discrete_time_bound.py
Fig. 4 (double integrator)      - experiments/e3_double_integrator_comparison.py
Fig. 5 (sensitivity sweeps)     - e4_statistics_sensitivity_ablation.py, sections B/C
Fig. 6 (theta/confidence trace) - inline script, single representative trial
Fig. 7 (measured compute cost)  - e4_statistics_sensitivity_ablation.py, section E
Fig. 8 (scalability)            - experiments/e5_multiactuator_scalability.py
Fig. 9 (KUKA)                   - testbeds/kuka_ftc.py
Fig. 10 (pendulum)              - testbeds/pendulum_ftc.py
Fig. 11 (heatmap)               - inline script over core/strategies.py, delta_max x budget grid
Fig. 12 (Pareto)                - derived from e3 + e4 computational-cost data
Table (conservatism, Sec 3.5.1) - e13_certificate_conservatism.json, computed
                                   analytically from P_trajectory_representative.npy
Table (extra baselines, Sec 5.3)- core/baselines_extra.py, e12_extra_baselines.json
Table (embedded compute, Sec 9.4)-e11_compute_benchmark.json

Known limitations of this package
----------------------------------
- The wheeled-robot (Husky) testbed is included but does NOT produce a
  working strategy comparison; reported honestly as incomplete
  (see notes/theory.md and the manuscript's appendix).
- No physical hardware is involved anywhere in this repository.
- adaptive_ftc and robust_mpc_ftc were validated only on the
  double-integrator testbed, not on KUKA/pendulum/scalability.
- The certified-budget analysis (e13) uses a representative regressor
  trajectory and a fixed worst-case initial condition, not a full
  distributional analysis over all tested initial conditions.
