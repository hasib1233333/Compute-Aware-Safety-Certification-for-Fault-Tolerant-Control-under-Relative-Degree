"""
core/detector.py

From-scratch implementation of an ANYTIME actuator-fault detector.

Fault model
-----------
Control-affine system  xdot = f(x) + g(x) u_actual,
with multiplicative actuator efficiency loss:
    u_actual = (I - diag(delta)) u_cmd,     delta_i in [0, delta_max]
delta_i = 0  -> actuator i healthy
delta_i -> delta_max -> actuator i has lost up to delta_max fraction of effectiveness.

We do NOT assume a specific robot's dynamics here. The detector observes,
at each control cycle, the commanded input u_cmd and a noisy measurement of
the actually-applied generalized force / actuation effect y (obtained by the
caller from state derivatives or motor current / torque sensing -- testbed-
specific, supplied externally). It regresses

    y_i  ~  (1 - delta_i) * u_cmd_i  + noise

online via recursive least squares (RLS) with forgetting factor, run for a
caller-specified number of "compute ticks" k per control cycle.

The key property this file exists to establish, empirically, is:
    ||delta_hat_k - delta_true||  is non-increasing in k (in expectation,
    under persistent excitation), i.e. this estimator has the ANYTIME
    property the theory in notes/theory.md depends on. That property is
    verified, not assumed -- see experiments/e0_detector_validation.py.
"""

import numpy as np


class RLSFaultDetector:
    """
    Per-actuator recursive least-squares estimator of efficiency loss delta_i.

    State per actuator i: scalar theta_i estimate of (1 - delta_i) (the
    *retained* effectiveness, in (0, 1]), with an associated scalar RLS
    covariance/precision term. Working with retained effectiveness rather
    than delta itself avoids sign ambiguity and keeps the regression
    linear-in-parameter: y_i = theta_i * u_cmd_i + noise.

    forgetting factor lam in (0, 1]: lam < 1 lets the estimator track
    time-varying / abruptly-changing faults (a fault that appears mid-episode)
    rather than only converging to a single fixed value over an infinite
    horizon, which is the realistic FTC setting.
    """

    def __init__(self, m, forgetting=0.98, theta_init=1.0, p_init=10.0,
                 excitation_eps=1e-3):
        self.m = m
        self.lam = forgetting
        self.theta = np.full(m, theta_init, dtype=float)
        self.P = np.full(m, p_init, dtype=float)   # scalar RLS "covariance" per actuator
        self.excitation_eps = excitation_eps
        self.n_ticks_total = 0

    def reset(self):
        self.theta[:] = 1.0
        self.P[:] = 10.0
        self.n_ticks_total = 0

    def step(self, u_cmd, y_obs, n_ticks=1):
        """
        Run n_ticks RLS updates using the SAME (u_cmd, y_obs) pair repeated,
        which is the correct anytime-compute abstraction when a single
        (u_cmd, y_obs) sample is available per control cycle but the caller
        wants to spend more per-cycle compute *refining against buffered
        recent samples* -- see step_buffered for the realistic multi-sample
        version used in the actual experiments. This single-sample version
        is kept because it has a closed-form per-tick contraction rate we
        use to validate the implementation against theory in
        experiments/e0_detector_validation.py.
        """
        u_cmd = np.asarray(u_cmd, dtype=float)
        y_obs = np.asarray(y_obs, dtype=float)
        for _ in range(max(1, n_ticks)):
            for i in range(self.m):
                u_i = u_cmd[i]
                if abs(u_i) < self.excitation_eps:
                    continue  # no information when actuator i is near-idle
                # scalar RLS update
                P_i = self.P[i]
                denom = self.lam + u_i * P_i * u_i
                K_i = (P_i * u_i) / denom
                err_i = y_obs[i] - self.theta[i] * u_i
                self.theta[i] = self.theta[i] + K_i * err_i
                self.P[i] = (P_i - K_i * u_i * P_i) / self.lam
                self.theta[i] = np.clip(self.theta[i], 0.02, 1.0)
            self.n_ticks_total += 1
        return self.delta_hat

    def step_buffered(self, u_buf, y_buf, n_ticks=1):
        """
        Realistic version: caller supplies a ring buffer of the last K
        (u_cmd, y_obs) samples collected during normal operation (K grows
        with elapsed wall-clock time, not with 'compute'). n_ticks controls
        how many RLS sweeps over that buffer are performed THIS control
        cycle -- this is the actual anytime-compute knob: more compute
        budget tau -> more sweeps over available data -> lower error, at
        fixed wall-clock/data availability. This is what all four testbed
        experiments use.
        """
        u_buf = np.asarray(u_buf, dtype=float)
        y_buf = np.asarray(y_buf, dtype=float)
        n_samples = u_buf.shape[0]
        if n_samples == 0:
            return self.delta_hat
        for _ in range(max(1, n_ticks)):
            idx = self.n_ticks_total % n_samples
            self.step(u_buf[idx], y_buf[idx], n_ticks=1)
        return self.delta_hat

    @property
    def delta_hat(self):
        return 1.0 - self.theta

    @property
    def uncertainty(self):
        """Per-actuator scalar proxy for estimation uncertainty (RLS P)."""
        return self.P.copy()
