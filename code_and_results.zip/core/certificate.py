"""
core/certificate.py

Implements the certificate from notes/theory.md Sec. 3-6:
  - eps_eta(k): high-confidence bound on ||theta_hat_k - theta_true||_inf,
    built from the RLS covariance P_k (deterministic) and a Gaussian
    tail bound with Bonferroni correction over m actuators.
  - Two-phase safety floor: Prop. 1 (Sec. 5) before the detector triggers
    (uses the hard design bound delta_max, NOT the statistical eps_eta --
    that bound is unconditional given theta_true in the assumed fault set),
    then the tighter post-reconfiguration floor (Sec. 6, derived below)
    once eps_eta(k) <= eps_trig, valid with probability >= 1-eta (the
    ONLY place randomness enters the overall claim).

Post-reconfiguration bound derivation (extends theory.md Sec. 6, written
out in full here since theory.md only sketched it):
  After trigger, controller solves the CBF-QP assuming effectiveness
  theta_hat (not theta_true). Constraint enforced:
      Lf_h + Lg_h * theta_hat * u  >=  -gamma h
  True derivative:
      hdot = Lf_h + Lg_h * theta_true * u
           = [Lf_h + Lg_h * theta_hat * u] + Lg_h * (theta_true - theta_hat) * u
           >= -gamma h - |Lg_h| * |theta_true - theta_hat| * |u|
           >= -gamma h - |Lg_h| * eps_trig * u_max      (w.p. >= 1-eta, by
                                                           definition of the
                                                           trigger + eps_eta)
  => rho_post := |Lg_h| * eps_trig * u_max  (same functional form as
     rho_max in Sec.4/5, but with eps_trig replacing delta_max -- since
     eps_trig is a DESIGN CHOICE, typically eps_trig << delta_max, this is
     why reconfiguration tightens the bound).
"""
import numpy as np
from scipy.stats import norm


def eps_eta_curve(P_hist, sigma, eta, m, z_precomputed=None):
    """
    P_hist: (K, m) array of per-actuator RLS precision P_i(k) over ticks.
    sigma : scalar noise-std proxy (assumed known/conservative design value).
    eta   : overall confidence failure probability budget.
    m     : number of actuators (for Bonferroni correction).
    z_precomputed: optional precomputed sub-Gaussian Chernoff constant
      sqrt(2*log(2m/eta)) to avoid repeated recomputation in hot loops.

    Uses the sub-Gaussian Chernoff concentration constant sqrt(2*log(2m/eta)),
    NOT the Gaussian-exact quantile norm.ppf(1-eta/(2m)). This matters:
    Assumption A5 states the noise is sub-Gaussian, a strictly weaker
    condition than exactly Gaussian, and the exact Gaussian quantile is
    only valid under the stronger assumption. The correction is derived,
    not asserted: the RLS estimation error theta_hat_k - theta is a
    weighted sum of the noise terms, weights r_i*P_k (standard RLS
    identity), and a linear combination of independent sub-Gaussian(sigma)
    variables with weights a_i is itself sub-Gaussian with parameter
    sigma*sqrt(sum a_i^2) = sigma*sqrt(P_k) (using sum r_i^2 = 1/P_k for
    the growing-window scalar RLS) -- giving the standard sub-Gaussian tail
    bound P(|theta_hat_k-theta|>t) <= 2 exp(-t^2/(2 sigma^2 P_k)), inverted
    at a per-actuator confidence eta/m (union bound over m actuators) to
    give t = sigma*sqrt(P_k)*sqrt(2*log(2m/eta)). This constant is
    approximately 1.49x the Gaussian-exact quantile at eta=0.10, m=1 (a
    real, non-trivial, more-conservative correction, not a rounding
    difference) -- verified numerically in
    experiments/e11_subgaussian_verification.py to confirm the more
    conservative bound does not change any qualitative experimental
    conclusion in this manuscript, only tightens the theoretical
    justification.
    Returns eps_eta(k) for k=1..K, deterministic given P_hist and design
    constants (no randomness other than what already produced P_hist,
    which -- per notes/theory.md -- does not depend on the noisy y_obs).
    """
    z = z_precomputed if z_precomputed is not None else np.sqrt(2 * np.log(2 * m / eta))
    P_max = np.max(P_hist, axis=1)
    return z * sigma * np.sqrt(np.maximum(P_max, 0.0))


def trigger_tick(eps_curve, eps_trig):
    idx = np.argmax(eps_curve <= eps_trig)
    if eps_curve[idx] > eps_trig:
        return None  # never triggers within the horizon given
    return idx


def prop1_floor(t, h0, rho, gamma):
    """Comparison-lemma floor for hdot >= -gamma*h - rho, h(0)=h0."""
    return (h0 + rho / gamma) * np.exp(-gamma * t) - rho / gamma


def two_phase_floor(t_hist, h0, t_trigger, rho_pre, rho_post, gamma):
    """
    t_hist     : (n,) array of wall-clock times (0 excluded, first entry = dt)
    h0         : h at t=0
    t_trigger  : wall-clock time detector triggers (None if never within horizon)
    rho_pre/post: pre/post-trigger perturbation bounds (Sec 4-5 / Sec 6)
    Returns (n,) floor array.
    """
    floor = np.zeros_like(t_hist)
    if t_trigger is None:
        return prop1_floor(t_hist, h0, rho_pre, gamma)
    pre_mask = t_hist <= t_trigger
    floor[pre_mask] = prop1_floor(t_hist[pre_mask], h0, rho_pre, gamma)
    h_at_trigger_floor = prop1_floor(np.array([t_trigger]), h0, rho_pre, gamma)[0]
    post_mask = ~pre_mask
    t_rel = t_hist[post_mask] - t_trigger
    floor[post_mask] = prop1_floor(t_rel, h_at_trigger_floor, rho_post, gamma)
    return floor
