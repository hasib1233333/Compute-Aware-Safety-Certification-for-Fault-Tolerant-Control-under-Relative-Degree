"""
core/strategies.py

Four controller strategies sharing the identical CBF-QP core, differing
ONLY in how/when they trust an actuator-effectiveness estimate. This
isolates the scientific variable: any performance/safety difference
between methods is attributable to the reconfiguration policy, not to
implementation differences elsewhere.

  no_ftc            : never detects, always assumes healthy (theta_hat=1).
  passive_ftc        : never detects; instead builds worst-case delta_max
                        conservatism into the CBF constraint AT ALL TIMES
                        (extra_margin = rho_max), matching the textbook
                        definition of passive FTC (robust design, no FDD).
  naive_active_ftc   : runs the SAME RLS detector as BFTC, but reconfigures
                        at a FIXED wall-clock time T_fixed regardless of
                        actual estimation confidence -- this is the
                        literal gap identified in the literature review
                        (active FTC papers assume detection completes
                        "fast enough" without formalizing the relationship
                        to available compute). Under generous compute this
                        looks fine; under scarce compute it reconfigures
                        on a bad estimate.
  bftc (proposed)    : same detector, but reconfigures only once the
                        certified confidence bound eps_eta(k) <= eps_trig,
                        i.e. compute-budget-aware, with the theoretical
                        guarantee from notes/theory.md.
"""
import numpy as np
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.detector import RLSFaultDetector
from core.certificate import eps_eta_curve


def run_strategy(strategy, theta_true, v0, v_max, a_push, u_lo, u_hi, gamma,
                  delta_max, dt_cycle, T, n_ticks_per_cycle, sigma, eta,
                  eps_trig, T_fixed_naive, seed, w_drift=0.0):
    """
    w_drift: constant disturbance added to vdot (e.g. gravity / downhill
    grade / wind), representing a real force that pushes the system toward
    the unsafe region REGARDLESS of the controller's commanded input. This
    is what makes actuator weakness genuinely dangerous: without it, a
    fault that only ever REDUCES effective actuation cannot cause an
    overshoot in a pure "push toward a ceiling" task (verified empirically
    -- see e3 run history: w_drift=0 gave 0% violations for EVERY strategy
    including no_ftc, which is a structural property of that scenario, not
    a null result). With w_drift>0, avoiding h<0 requires ACTIVE braking
    (u<0) as h shrinks, and a weak actuator under-delivers on that braking
    -- the realistic FTC danger mode (e.g. adaptive cruise control on a
    downhill grade, thrust loss while hovering against gravity).
    """
    assert strategy in ("no_ftc", "passive_ftc", "naive_active_ftc",
                         "bftc_binary", "bftc")
    rng = np.random.default_rng(seed)
    det = RLSFaultDetector(1, forgetting=1.0, theta_init=1.0, p_init=100.0)
    n_cycles = int(T / dt_cycle)
    v = v0
    rho_max = 1.0 * delta_max * u_hi
    from scipy.stats import norm as _norm
    z_precomp = np.sqrt(2 * np.log(2 * 1 / eta))  # sub-Gaussian Chernoff constant (m=1), corrected

    h_hist = np.zeros(n_cycles)
    t_hist = np.zeros(n_cycles)
    v_hist = np.zeros(n_cycles)
    triggered = False
    t_trigger = None

    uses_detector = strategy in ("naive_active_ftc", "bftc_binary", "bftc")

    for k in range(n_cycles):
        h = v_max - v
        t_now = (k + 1) * dt_cycle

        if strategy == "no_ftc":
            theta_hat_eff, extra_margin = 1.0, 0.0
        elif strategy == "passive_ftc":
            theta_hat_eff, extra_margin = 1.0, rho_max
        elif strategy in ("naive_active_ftc", "bftc_binary"):
            # binary: assume healthy until triggered, then fully trust theta_hat
            theta_hat_eff = (1.0 - det.delta_hat[0]) if triggered else 1.0
            extra_margin = 0.0
        elif strategy == "bftc":
            # continuous/graceful: ALWAYS use the current point estimate
            # (from cycle 1), with a margin proportional to the CURRENT
            # certified uncertainty radius, clipped to the design range
            # delta_max (P can be uninformative early -- e.g. p_init --
            # giving eps_eta bigger than the physically meaningful range;
            # clipping to delta_max is the honest statement "we are never
            # LESS certain than the hard design bound already gives us").
            theta_hat_eff = 1.0 - det.delta_hat[0]
            if k == 0:
                eps_now = delta_max  # no data yet -> full design-bound uncertainty
            else:
                P_now = det.uncertainty.reshape(1, -1)
                eps_now = min(eps_eta_curve(P_now, sigma, eta, m=1, z_precomputed=z_precomp)[-1], delta_max)
            extra_margin = eps_now * u_hi   # |Lg_h|=1 for this system
        u_upper_num = gamma * h - extra_margin - w_drift
        u_upper = u_upper_num / max(theta_hat_eff, 1e-3)
        u_upper = min(u_hi, u_upper)
        u_cmd = np.clip(a_push, u_lo, u_upper) if u_upper >= u_lo else u_lo
        u_actual = w_drift + theta_true * u_cmd

        if uses_detector and (strategy == "bftc" or not triggered):
            for _ in range(n_ticks_per_cycle):
                y_obs = theta_true * u_cmd + rng.normal(0, sigma)
                det.step(np.array([u_cmd]), np.array([y_obs]), n_ticks=1)

            if strategy == "naive_active_ftc" and not triggered:
                if t_now >= T_fixed_naive:
                    triggered = True
                    t_trigger = t_now
            elif strategy == "bftc_binary" and not triggered:
                P_now = det.uncertainty.reshape(1, -1)
                eps_k = eps_eta_curve(P_now, sigma, eta, m=1, z_precomputed=z_precomp)[-1]
                if eps_k <= eps_trig:
                    triggered = True
                    t_trigger = t_now

        v = v + dt_cycle * u_actual
        t_hist[k] = t_now
        h_hist[k] = v_max - v
        v_hist[k] = v

    theta_hat_final = (1.0 - det.delta_hat[0]) if uses_detector else None
    return dict(
        strategy=strategy, theta_true=float(theta_true), v0=float(v0),
        t_hist=t_hist, h_hist=h_hist, v_hist=v_hist,
        h_min=float(h_hist.min()),
        safety_violation=bool(h_hist.min() < 0),   # TRUE physical constraint (h>=0), not the theory floor
        t_trigger=float(t_trigger) if t_trigger is not None else None,
        theta_hat_final=float(theta_hat_final) if theta_hat_final is not None else None,
        theta_est_err_final=(abs(theta_hat_final - theta_true)
                              if theta_hat_final is not None else None),
        # performance metric: time-averaged velocity relative to v_max,
        # i.e. how well the robot actually achieves its nominal task
        # (push toward v_max) -- passive-FTC's conservatism should show up
        # here as a real, measurable performance cost, not just an
        # abstract "conservatism" claim.
        mean_v_frac=float(np.mean(v_hist) / v_max),
        final_v_frac=float(v_hist[-1] / v_max),
    )
