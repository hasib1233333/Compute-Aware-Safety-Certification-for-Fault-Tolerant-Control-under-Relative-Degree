"""
core/baselines_extra.py

Two additional baselines, added specifically to broaden the comparison
beyond No-FTC/Passive-FTC/Naive-Active-FTC/BFTC-binary/BFTC, representing
two established FTC design philosophies not otherwise covered:

  adaptive_ftc     : classical gradient-based (MIT-rule) online adaptive
                     control. Maintains a continuously-updated point
                     estimate of actuator effectiveness via a Lyapunov/
                     gradient adaptation law -- NOT the RLS detector used
                     elsewhere in this manuscript -- and uses that
                     estimate directly in the CBF filter with NO
                     confidence margin and NO detection window/trigger.
                     This represents the standard adaptive-control
                     philosophy: continuously adapt, continuously trust
                     the current belief. This is a representative,
                     textbook-standard algorithm of this design class
                     (see e.g. Ioannou & Sun, "Robust Adaptive Control";
                     Astrom & Wittenmark, "Adaptive Control"), NOT a
                     reimplementation of any specific recent paper.

  robust_mpc_ftc   : short receding-horizon robust MPC. At every control
                     cycle, solves a small constrained optimization over
                     a horizon N, using the WORST-CASE fault bound
                     theta_min throughout the horizon (no online
                     estimation at all -- a robust, not adaptive, design)
                     to select the current control action. This is a
                     representative, standard robust-MPC-for-FTC design
                     (tube/worst-case-style, as in e.g. Bououden et al.
                     2021, Nan et al. 2022 -- see references.bib), NOT a
                     faithful reimplementation of either specific paper's
                     exact formulation.

Both share the SAME plant, fault model, and safety specification as
core/strategies.py's double-integrator scenario, so that any difference
in behavior is attributable to the FTC design philosophy, not to
incidental implementation differences.
"""
import numpy as np
from scipy.optimize import minimize


def run_adaptive_ftc(theta_true, v0, v_max, a_push, u_lo, u_hi, gamma,
                      delta_max, dt_cycle, T, sigma, seed, w_drift=0.0,
                      gamma_adapt=5.0):
    """
    Gradient (MIT-rule) adaptive law:
        theta_hat_{k+1} = theta_hat_k + dt * gamma_adapt * e_pred_k * u_cmd_k
    where e_pred_k = y_obs_k - theta_hat_k * u_cmd_k is the instantaneous
    prediction error on the (noisy) measured actuator effect. theta_hat is
    used DIRECTLY in the CBF filter every cycle, with no confidence
    margin and no trigger -- the defining feature of this baseline class.
    """
    rng = np.random.default_rng(seed)
    n_cycles = int(T / dt_cycle)
    v = v0
    theta_hat = 1.0  # start at healthy assumption, same as all other strategies

    h_hist = np.zeros(n_cycles)
    v_hist = np.zeros(n_cycles)

    for k in range(n_cycles):
        h = v_max - v
        theta_hat_eff = np.clip(theta_hat, 1e-3, 1.5)  # keep away from 0/instability

        u_upper = (gamma * h - w_drift) / theta_hat_eff
        u_upper = min(u_hi, u_upper)
        u_cmd = float(np.clip(a_push, u_lo, u_upper)) if u_upper >= u_lo else u_lo

        u_actual = theta_true * u_cmd
        y_obs = theta_true * u_cmd + rng.normal(0, sigma)

        e_pred = y_obs - theta_hat * u_cmd
        theta_hat = theta_hat + dt_cycle * gamma_adapt * e_pred * u_cmd * 1e-2

        v = v + dt_cycle * (w_drift + u_actual)
        h_hist[k] = v_max - v
        v_hist[k] = v

    h_min = float(h_hist.min())
    mean_v_frac = float(np.mean(v_hist) / v_max)
    return dict(strategy="adaptive_ftc", theta_true=float(theta_true), h_min=h_min,
                safety_violation=bool(h_min < 0), mean_v_frac=mean_v_frac)


def run_robust_mpc_ftc(theta_true, v0, v_max, a_push, u_lo, u_hi, gamma,
                        delta_max, dt_cycle, T, sigma, seed, w_drift=0.0,
                        horizon=5):
    """
    Short receding-horizon robust MPC. At each cycle, solves:
        min_{u_0..u_{N-1}}  sum_i (u_i - a_push)^2
        s.t.  v_{i+1} = v_i + dt*(w_drift + theta_min*u_i)   [WORST CASE]
              v_max - v_{i+1} >= 0  for all i in horizon      [robust safety]
              u_lo <= u_i <= u_hi
    using theta_min = 1 - delta_max throughout -- no online estimation,
    a purely robust (not adaptive) design, distinguishing it architecturally
    from both BFTC and the adaptive_ftc baseline above.
    """
    rng = np.random.default_rng(seed)
    n_cycles = int(T / dt_cycle)
    v = v0
    theta_min = 1.0 - delta_max

    h_hist = np.zeros(n_cycles)
    v_hist = np.zeros(n_cycles)

    def cost(u_seq):
        return float(np.sum((u_seq - a_push) ** 2))

    def rollout_v(u_seq, v_start):
        vs = np.zeros(horizon)
        vv = v_start
        for i in range(horizon):
            vv = vv + dt_cycle * (w_drift + theta_min * u_seq[i])
            vs[i] = vv
        return vs

    def safety_constraint(u_seq):
        vs = rollout_v(u_seq, v)
        return v_max - vs  # must be >= 0 for all horizon steps

    u_prev_solution = np.full(horizon, a_push)

    for k in range(n_cycles):
        h = v_max - v
        bounds = [(u_lo, u_hi)] * horizon
        cons = [{"type": "ineq", "fun": safety_constraint}]
        res = minimize(cost, u_prev_solution, method="SLSQP", bounds=bounds,
                        constraints=cons, options=dict(maxiter=50, ftol=1e-6))
        if res.success:
            u_seq = res.x
        else:
            # infeasible within horizon at max braking -> apply max braking
            u_seq = np.full(horizon, u_lo)
        u_cmd = float(np.clip(u_seq[0], u_lo, u_hi))
        u_prev_solution = np.concatenate([u_seq[1:], [a_push]])

        u_actual = theta_true * u_cmd
        v = v + dt_cycle * (w_drift + u_actual)
        h_hist[k] = v_max - v
        v_hist[k] = v

    h_min = float(h_hist.min())
    mean_v_frac = float(np.mean(v_hist) / v_max)
    return dict(strategy="robust_mpc_ftc", theta_true=float(theta_true), h_min=h_min,
                safety_violation=bool(h_min < 0), mean_v_frac=mean_v_frac)
