"""
core/cbf_filter.py

Standard exponential-CBF quadratic-program safety filter.
NOT the novel contribution of this paper -- this is textbook (Ames et al.,
"Control Barrier Functions: Theory and Applications", 2019) machinery,
implemented from scratch here only because every method under comparison
(baselines included) needs a shared, identical safety-filter implementation
so that differences in results are attributable to the FTC strategy, not to
differences in QP filter implementation.

    minimize_u   || u - u_des ||^2
    subject to   Lf_h + Lg_h @ u  >=  -gamma * h        (CBF constraint)
                 u_lo <= u <= u_hi                        (actuator limits)

Optionally accepts an estimated actuator-gain vector theta_hat to correct
the constraint for a KNOWN/estimated fault (used by active-FTC and BFTC
after reconfiguration; theta_hat = ones(m) recovers the unfaulted filter,
used by the no-FTC and passive-FTC baselines).
"""
import numpy as np
import cvxpy as cp


class CBFQPFilter:
    def __init__(self, m, u_lo, u_hi, gamma=1.0):
        self.m = m
        self.u_lo = np.asarray(u_lo, dtype=float)
        self.u_hi = np.asarray(u_hi, dtype=float)
        self.gamma = gamma

    def filter(self, u_des, h, Lf_h, Lg_h, theta_hat=None, extra_margin=0.0):
        """
        u_des    : (m,) desired/nominal input
        h        : scalar barrier value at current state
        Lf_h     : scalar
        Lg_h     : (m,) row vector s.t. hdot = Lf_h + Lg_h @ u_actual
        theta_hat: (m,) assumed actuator effectiveness (1=healthy). If the
                   filter is asked to enforce safety of u_actual = diag(theta_hat) u,
                   the constraint becomes Lf_h + (Lg_h * theta_hat) @ u >= -gamma*h.
        extra_margin: subtract extra_margin from the RHS bound (used by the
                   passive-FTC baseline to build in worst-case conservatism).
        """
        theta_eff = np.ones(self.m) if theta_hat is None else np.asarray(theta_hat, dtype=float)
        u = cp.Variable(self.m)
        Lg_eff = Lg_h * theta_eff
        constraints = [
            Lf_h + Lg_eff @ u >= -self.gamma * h + extra_margin,
            u >= self.u_lo,
            u <= self.u_hi,
        ]
        obj = cp.Minimize(cp.sum_squares(u - u_des))
        prob = cp.Problem(obj, constraints)
        try:
            prob.solve(solver=cp.OSQP, verbose=False)
        except Exception:
            prob.solve(verbose=False)
        if u.value is None:
            # infeasible QP (can happen transiently under severe faults) ->
            # fall back to the most conservative admissible action: full
            # braking / most-safety-improving corner of the box constraint,
            # chosen along -Lg_eff direction, clipped to bounds.
            direction = -np.sign(Lg_eff)
            u_fallback = np.where(direction >= 0, self.u_hi, self.u_lo)
            return u_fallback, False
        return np.asarray(u.value).flatten(), True
