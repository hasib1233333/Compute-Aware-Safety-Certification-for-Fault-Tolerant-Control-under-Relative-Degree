"""
core/multiactuator_filter.py

Fast solver for: minimize sum_i (u_i - u_des_i)^2
                  s.t.      sum_i c_i * u_i >= b,   u_i in [lo_i, hi_i]
with c_i > 0 for all i (true here: c_i = theta_hat_i in (0,1]).

Used for the multi-actuator scalability experiment (Sec: Prop 5). A
generic QP solver (cvxpy/OSQP, core/cbf_filter.py) is too slow to call
per-timestep across thousands of trials at m up to 16 (verified: cvxpy
per-call overhead made even single-actuator sweeps time out earlier in
this project -- see session history). This bisection solver is
mathematically exact for this problem structure (single linear
constraint, box bounds, all c_i > 0 so the constrained value
c^T u(lambda) is provably monotonically non-decreasing in the Lagrange
multiplier lambda >= 0), not an approximation, and is verified against
cvxpy below before being trusted in the actual experiment.
"""
import numpy as np


def solve_multiactuator(u_des, c, b, lo, hi, tol=1e-9, max_iter=100):
    """
    Returns u minimizing ||u-u_des||^2 s.t. c.u >= b, lo<=u<=hi, c_i>0.
    """
    u_des = np.asarray(u_des, dtype=float)
    c = np.asarray(c, dtype=float)
    lo = np.asarray(lo, dtype=float)
    hi = np.asarray(hi, dtype=float)
    assert np.all(c > 0), "solver assumes c_i > 0 for all i"

    def u_of_lambda(lam):
        return np.clip(u_des + lam * c / 2.0, lo, hi)

    def constraint_value(lam):
        return c @ u_of_lambda(lam)

    # lambda=0: is the unconstrained-in-box optimum already feasible?
    if constraint_value(0.0) >= b:
        return u_of_lambda(0.0)

    # bracket lambda: find lam_hi such that constraint is satisfied
    lam_lo, lam_hi = 0.0, 1.0
    while constraint_value(lam_hi) < b:
        lam_hi *= 2.0
        if lam_hi > 1e12:
            # infeasible even at max lambda (all actuators saturated at hi)
            return u_of_lambda(lam_hi)
    for _ in range(max_iter):
        lam_mid = 0.5 * (lam_lo + lam_hi)
        if constraint_value(lam_mid) < b:
            lam_lo = lam_mid
        else:
            lam_hi = lam_mid
        if lam_hi - lam_lo < tol:
            break
    return u_of_lambda(lam_hi)


def _verify_against_cvxpy(n_checks=30, seed=0):
    """Correctness check against the generic cvxpy/OSQP solver already
    used elsewhere in this project (core/cbf_filter.py). Run once at
    import/test time, not in the hot loop."""
    import cvxpy as cp
    rng = np.random.default_rng(seed)
    max_err = 0.0
    for _ in range(n_checks):
        m = rng.integers(1, 9)
        u_des = rng.uniform(-3, 3, size=m)
        c = rng.uniform(0.05, 1.0, size=m)
        lo = np.full(m, -3.0)
        hi = np.full(m, 3.0)
        b = rng.uniform(-5, 5)

        u_fast = solve_multiactuator(u_des, c, b, lo, hi)

        u = cp.Variable(m)
        prob = cp.Problem(cp.Minimize(cp.sum_squares(u - u_des)),
                           [c @ u >= b, u >= lo, u <= hi])
        prob.solve(solver=cp.OSQP)
        if u.value is None:
            continue
        err = np.max(np.abs(u_fast - u.value))
        max_err = max(max_err, err)
    return max_err


def solve_multiactuator_upper(u_des, c, b, lo, hi, tol=1e-9, max_iter=100):
    """
    Returns u minimizing ||u-u_des||^2 s.t. c.u <= b, lo<=u<=hi, c_i>0.
    Derived via the substitution w = -u (NOT a naive sign flip on c, which
    would violate solve_multiactuator's c_i>0 assumption):
        minimize ||u-u_des||^2  s.t. c.u <= b
      = minimize ||(-w)-u_des||^2 = ||w-(-u_des)||^2  s.t. c.(-w) <= b
      = minimize ||w-(-u_des)||^2  s.t. c.w >= -b,  w in [-hi,-lo]
    then u = -w. c stays positive throughout, so solve_multiactuator's
    assumption is respected, not violated.
    """
    w = solve_multiactuator(-np.asarray(u_des), c, -b, -np.asarray(hi), -np.asarray(lo),
                             tol=tol, max_iter=max_iter)
    return -w


def _verify_upper_against_cvxpy(n_checks=30, seed=1):
    import cvxpy as cp
    rng = np.random.default_rng(seed)
    max_err = 0.0
    for _ in range(n_checks):
        m = rng.integers(1, 9)
        u_des = rng.uniform(-3, 3, size=m)
        c = rng.uniform(0.05, 1.0, size=m)
        lo = np.full(m, -3.0)
        hi = np.full(m, 3.0)
        b = rng.uniform(-5, 5)

        u_fast = solve_multiactuator_upper(u_des, c, b, lo, hi)

        u = cp.Variable(m)
        prob = cp.Problem(cp.Minimize(cp.sum_squares(u - u_des)),
                           [c @ u <= b, u >= lo, u <= hi])
        prob.solve(solver=cp.OSQP)
        if u.value is None:
            continue
        err = np.max(np.abs(u_fast - u.value))
        max_err = max(max_err, err)
    return max_err


if __name__ == "__main__":
    err = _verify_against_cvxpy()
    print(f"[>=] max abs error vs cvxpy/OSQP over 30 random checks: {err:.2e}")
    assert err < 1e-4, "bisection solver (>=) disagrees with generic QP solver"
    err2 = _verify_upper_against_cvxpy()
    print(f"[<=] max abs error vs cvxpy/OSQP over 30 random checks: {err2:.2e}")
    assert err2 < 1e-4, "bisection solver (<=) disagrees with generic QP solver"
    print("PASSED: both fast solvers verified correct.")
