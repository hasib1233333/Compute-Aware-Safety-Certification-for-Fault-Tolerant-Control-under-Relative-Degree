# BFTC: Budgeted Fault-Tolerant Control — theory notes (working draft)

Status: proposition-level, proof sketch below has been checked against the
detector implementation empirically (experiments/e0_detector_validation.py,
e1_covariance_monotonicity.py) but NOT yet independently proof-checked by a
second method or a human control theorist. Treat as "derived, not yet
verified to publication confidence."

## Revision log (honesty trail)
- v0 (initial): assumed the RLS point-estimate error ||delta_hat_k -
  delta_true|| itself is deterministically non-increasing in compute ticks
  k. Empirically FALSIFIED in e0_detector_validation.py: 52-60/60 trials
  show local upticks (max magnitude ~9e-4) even with forgetting=1.0,
  because a noisy estimator's error is a stochastic process whose
  EXPECTATION shrinks, not every sample path.
- v1 (current): the RLS covariance/precision term P_k IS deterministically
  non-increasing (verified in e1_covariance_monotonicity.py, 0/200
  violations even under 250x inflated noise, because the P-update never
  reads the noisy observation y_obs -- it depends only on which regressors
  u_cmd were persistently exciting). The certificate is built on P_k with
  an explicit confidence level eta, not on a deterministic point-estimate
  bound.

## 1. Fault model
Control-affine system: xdot = f(x) + g(x) u_actual
Actuator efficiency loss: u_actual = diag(theta) u_cmd, theta_i in
[theta_min, 1], theta_min = 1 - delta_max known design bound.
theta_i = 1 (healthy) by default; a fault sets some theta_i < 1, either at
t=0 (evaluated case) or at an unknown onset time (evaluated case).

## 2. Safety specification
Safe set C = {x : h(x) >= 0}, h assumed to have relative degree 1 w.r.t.
u_actual (standard CBF setting; higher relative degree needs the standard
HOCBF extension, not attempted here — an explicit limitation).
Nominal controller pi_0 renders C forward invariant under HEALTHY dynamics:
  L_f h(x) + L_g h(x) pi_0(x) >= -alpha(h(x))     for all x in C,
alpha a class-K function (we use alpha(h) = gamma h, gamma > 0, i.e. the
standard exponential CBF, for a closed-form comparison bound in Sec. 4).

## 3. Anytime detector (core/detector.py)
Per-actuator scalar RLS regression y_i = theta_i u_cmd_i + noise (noise
sub-Gaussian with known/estimated proxy variance sigma_i^2), growing window
(forgetting=1) during the active detection phase. Precision term:
  P_i(0) = P_0,   P_i(k) = P_i(k-1) - K_i(k) u_cmd_i(k) P_i(k-1)
This is the standard RLS covariance recursion; it does not depend on
y_obs, so P_i(k) is a DETERMINISTIC function of the excitation sequence
{u_cmd_i(1..k)} alone. Empirically confirmed monotonically non-increasing
(Sec. "Revision log"); this also follows from the standard RLS derivation
(P_i(k) = P_i(k-1) - (P_i(k-1) u_i)^2 / (1 + u_i^2 P_i(k-1)), and the
subtracted term is always >= 0 for real u_i).

Confidence bound (standard linear-Gaussian regression fact, not novel):
for Gaussian-ish regression noise with proxy std sigma_i,
  P( |theta_hat_i(k) - theta_i| <= z_{1-eta/(2m)} * sigma_i * sqrt(P_i(k)) for all i )
    >= 1 - eta                                                        (*)
via a per-actuator confidence interval and a union bound over m actuators
(Bonferroni; conservative but simple and defensible).

Define the certified error radius:
  eps_eta(k) := z_{1-eta/(2m)} * sigma_max * sqrt(P_max(k))
where sigma_max = max_i sigma_i, P_max(k) = max_i P_i(k). eps_eta(k) is
deterministically non-increasing in k (composition of a non-increasing
function with monotone P_max). This is the corrected ANYTIME PROPERTY the
theory needs, now honestly probabilistic rather than falsely deterministic.

Detection trigger: reconfigure once eps_eta(k) <= eps_trig (a design
threshold). Worst-case ticks-to-trigger K*(tau_budget) = min{k :
eps_eta(k) <= eps_trig}, monotonically non-increasing in tau_budget (more
compute per cycle -> more RLS ticks per unit wall-clock time -> smaller K*
in ticks, and CRUCIALLY smaller in wall-clock time T_detect = K* * Delta_t
/ ticks_per_cycle(tau_budget)).

## 4. Safety degradation during the (undetected-fault) window
While theta != theta_hat (fault present but not yet trusted), the
controller still applies pi_0 (uncompensated) OR a provisional
compensation using the not-yet-confident theta_hat -- two sub-cases;
give the WORSE case (uncompensated) here, since it upper-bounds the
better case:
  u_actual = diag(theta) pi_0(x),   theta in [theta_min, 1]^m (elementwise)

  hdot = L_f h(x) + L_g h(x) diag(theta) pi_0(x)
       = [L_f h(x) + L_g h(x) pi_0(x)] - L_g h(x) diag(1-theta) pi_0(x)
       >= -alpha(h(x)) - L_g h(x) diag(1-theta) pi_0(x)

  Let rho_max := sup_{x in C_epsilon} || L_g h(x) ||_1 * delta_max *
                 || pi_0(x) ||_inf
  (C_epsilon a slightly enlarged compact operating region around C over
  which pi_0 and L_g h are bounded -- required regularity assumption,
  stated explicitly as a limitation: this needs C to be compact or pi_0,
  L_g h to be globally bounded, which is testbed-dependent and checked
  numerically per testbed rather than assumed).

  => hdot >= -alpha(h(x)) - rho_max during the detection window.

## 5. Comparison-lemma certificate (Prop. 1, proof sketch)
With alpha(h) = gamma h:
  Let beta(t) solve  betadot = -gamma*beta - rho_max,  beta(0) = h(x(0)).
  Closed form: beta(t) = (h(x0) + rho_max/gamma) * exp(-gamma t) - rho_max/gamma
  By the comparison lemma (Khalil, Nonlinear Systems, Lemma 3.4, standard
  tool -- NOT a novel result on its own), h(x(t)) >= beta(t) for all
  t in [0, T_detect], PROVIDED the scalar bound hdot >= -gamma h - rho_max
  holds throughout (Sec. 4), which holds with probability >= 1-eta over
  the randomness of the detector's observations (the "with probability"
  qualifier is inherited from eps_eta and only matters for deciding WHEN
  T_detect is reached, not for the hdot inequality itself, which is a
  worst-case bound over ALL theta in the assumed fault set — no
  probability involved there).

PROP 1 (certificate): For a given tau_budget, delta_max, confidence level
eta, and initial condition x(0) with h(x(0)) = h0, the state satisfies
  h(x(t)) >= (h0 + rho_max/gamma) exp(-gamma t) - rho_max/gamma
for t in [0, T_detect(tau_budget)], with probability >= 1 - eta, after
which the reconfigured controller (Sec. 6) restores hdot >= -gamma h -
O(eps_trig) (residual bias from imperfect but now-confident estimate).

This is a genuinely testable claim: Sec 4-5 predict a FLOOR on h(t); the
testbed experiments log the empirically observed min h(t) during the
detection window and check it against the predicted floor. If the
empirical min ever falls BELOW the predicted floor more often than eta
fraction of trials, the theory (or, more likely, an unstated regularity
assumption / rho_max estimate) is wrong and must be reported as such, not
hidden.

## 6. Reconfiguration
theta_hat considered trustworthy once eps_eta(k) <= eps_trig. Reconfigured
input: u_recon = diag(theta_hat)^{-1} pi_0(x), theta_hat_i clipped away
from 0 (theta_min bound) to keep this well-posed. This is the standard
control-reallocation idea (present throughout the FTC literature reviewed
in related work); it is NOT the novel component of BFTC -- the novel
component is Sec. 3-5, the anytime/compute-budget-indexed certificate.

## 7. Known limitations to state explicitly in the paper (not hide)
- Requires relative-degree-1 h (no HOCBF extension attempted).
- rho_max requires a compact/bounded operating region; estimated
  numerically per testbed, not derived in closed form for all four.
- Confidence bound uses a Bonferroni union bound (simple, provably valid,
  but conservative -- tighter simultaneous confidence regions exist and
  are future work).
- Assumes multiplicative efficiency-loss fault model only; does not cover
  additive bias faults, sensor faults, or complete lock-in-place failures
  (theta_i essentially 0, near the numerical clipping boundary, is an
  edge case handled by theta_min clipping but not separately analyzed).
- Persistent excitation of pi_0 is REQUIRED for P_i(k) to shrink for
  actuator i at all; an actuator command that is exactly 0 throughout
  (e.g. unused DOF for a given task) is undetectable and must be
  reported as such per-testbed, not silently assumed away.

## 8. New propositions (added in response to review: "make the theory
## difficult to improve"). Each is checked against what Sec 1-7 already
## established -- no proposition here introduces an assumption not
## already stated, except where explicitly flagged.

### Prop 2 (Monotonicity of the certified floor in compute budget)
Claim: beta(T_detect(tau)) is non-decreasing in tau (compute budget).
Proof:
  (i) eps_eta(k) is non-increasing in k (Sec 3, verified).
  (ii) For tau_1 <= tau_2 (ticks per control cycle), after wall-clock time
       t, cumulative ticks satisfy k(tau_2, t) >= k(tau_1, t) (more
       ticks/cycle -> more cumulative ticks by time t). By (i),
       eps_eta(k(tau_2,t)) <= eps_eta(k(tau_1,t)) for all t.
  (iii) T_detect(tau) := inf{t : eps_eta(k(tau,t)) <= eps_trig}. By (ii),
        the tau_2 curve reaches any fixed threshold eps_trig no later
        than the tau_1 curve: T_detect(tau_2) <= T_detect(tau_1). I.e.
        T_detect is non-increasing in tau.
  (iv) beta(t) = (h0 + rho_max/gamma) exp(-gamma t) - rho_max/gamma is
       STRICTLY DECREASING in t (assuming h0 >= 0, rho_max, gamma > 0:
       the coefficient on exp(-gamma t) is positive, and exp(-gamma t)
       is strictly decreasing).
  (v) Composing a non-increasing function (iii) with a strictly
      decreasing function (iv): beta(T_detect(tau)) is non-decreasing in
      tau. QED.
Interpretation: more compute budget NEVER makes the certified worst-case
safety floor worse -- a basic sanity property a "certificate" should have,
now proven rather than just empirically observed (Fig. sensitivity plots
show the empirical safety violation rate is non-increasing in budget,
consistent with but not identical to this claim, which is about the
CERTIFIED floor specifically).

### Prop 3 (Computational complexity)
Per-tick RLS update (Sec 3, core/detector.py): O(1) per actuator (scalar
update), O(m) across m actuators per tick. With tau ticks/cycle and
n_cycles = T/dt cycles per trial: total detector cost per trial =
O(m * tau * T/dt). Memory: O(m) (theta_hat_i, P_i per actuator, no growing
buffer needed since RLS is a fixed-size recursive update -- CONFIRMED by
inspection of core/detector.py: no history array is required for the
recursion itself, only for logging/diagnostics in these experiments).
CBF-QP filter cost depends on the constraint structure: for the
single-constraint-single-actuator case used in double-integrator/cartpole/
Husky (Sec 5,6,7), the filter is O(1) closed-form (verified: our
implementation uses closed-form clipping, not a generic solver, in the
hot path). For the multi-actuator single-constraint case (Sec [scalability
experiment]), the filter is a singly-linearly-constrained box-QP, solved
via bisection on a scalar Lagrange multiplier: O(m log(1/tol)) per solve,
verified against a generic QP solver (cvxpy/OSQP) for correctness on a
sample of states (see experiments/e5_multiactuator_scalability.py).

### Prop 4 (Convergence under persistent excitation) -- adapts a KNOWN
result, does not claim a new proof of RLS convergence itself.
If the regressor sequence {r_i(k)} for actuator i is persistently
exciting (PE) -- there exist alpha, N > 0 such that
(1/N) sum_{j=k}^{k+N-1} r_i(j)^2 >= alpha for all k -- then the RLS
estimate theta_hat_i(k) converges to theta_i almost surely as k -> infinity
under standard noise conditions (zero-mean, bounded-variance, uncorrelated
with the regressor); see Ljung (1999, Ch. 8-9) for the general
prediction-error/least-squares convergence and consistency theory, and
Bruce, Goel & Bernstein (2021) for necessary and sufficient PE conditions
specifically for RLS global asymptotic stability. We do not reprove this
classical result; what IS new here is combining it with the covariance-
based anytime confidence radius (Sec 3) to get a COMPUTE-INDEXED,
finite-sample (not just asymptotic) confidence statement -- Prop 1 is a
finite-k, high-probability statement, which is a different (and for a
real-time deployment question, more useful) claim than asymptotic
convergence as k -> infinity. A6 (persistent excitation, Sec 7 limitations)
is the exact hypothesis this proposition needs; we do not claim
convergence without it and Sec 7 already flags actuators that are
never excited as un-diagnosable.

### Corollary 1 (Robustness under bounded additive disturbance)
If the true dynamics include an additional bounded disturbance d(t)
entering additively into hdot (hdot = Lf_h + Lg_h . u_actual + d(t),
|d(t)| <= d_max, e.g. wind, unmodeled friction, or the w_drift terms
already used in Sec 5-7's experiments), then Prop 1 holds verbatim with
rho_max replaced by rho_max' = rho_max + d_max. Proof: identical
comparison-lemma argument (Sec 4-5), since the derivation only used a
lower bound on hdot of the form -gamma h - (perturbation terms), and d(t)
enters as one more perturbation term bounded by d_max, additively
combining with the existing fault-induced term. This is not a new proof
technique -- it is noting explicitly that Sec 5-7's w_drift terms were
ALREADY instances of this corollary, not a separate mechanism, and stating
the general form once rather than re-deriving it per testbed.

### Prop 5 (Multi-actuator generalization, explicit m-dependence)
Prop 1 as stated in Sec 4-5 is ALREADY general in m: rho_max :=
sup_x ||L_g h(x)||_1 * delta_max * ||pi_0(x)||_inf uses the L1/Linf norms
over the m-dimensional Lg_h(x) and pi_0(x), valid for any m >= 1. What
changes with m is the CONFIDENCE radius: eps_eta(k) = z_{1-eta/(2m)} *
sigma * sqrt(P_max(k)), where the Bonferroni factor z_{1-eta/(2m)} is
INCREASING in m (need a stricter per-actuator confidence level to hold
the OVERALL failure probability at eta across m simultaneous per-actuator
confidence intervals). This is a real, quantifiable "cost of scale": for
fixed eta and fixed per-actuator noise/excitation, T_detect(tau) is
non-decreasing in m (more actuators to jointly certify -> need tighter
per-actuator bounds -> takes at least as long). This is validated
empirically, not just asserted, in
experiments/e5_multiactuator_scalability.py (Sec [scalability] of the
manuscript).

### Prop 6 (Discrete-time safety bound with explicit truncation error)
Addresses the most consequential open item flagged by review: Prop 1 is
continuous-time; here is the discrete-time version, Option B (explicit
discretization-error term), not Option A (a full discrete-time
reformulation of the whole certificate, which would be a much larger
undertaking and is NOT what this does).

NEW ASSUMPTION A8 (bounded second derivative): h is twice continuously
differentiable along trajectories in the relevant compact operating
region, with |h''(t)| <= M for a known/boundable constant M. This is
an ADDITIONAL assumption beyond A1-A7, stated explicitly, not folded
silently into existing ones.

Derivation (forward Euler, the scheme used in every experiment in this
manuscript): by Taylor's theorem with Lagrange remainder,
  h(t_k + dt) = h(t_k) + dt*h'(t_k) + (dt^2/2)*h''(xi_k),  xi_k in (t_k, t_k+dt)
so, using A8:
  h_{k+1} >= h_k + dt*h'_k - (dt^2/2)*M
Combining with the continuous-time Phase-1 bound (Sec 4, h'_k >= -gamma h_k
- rho_max):
  h_{k+1} >= h_k + dt*(-gamma h_k - rho_max) - (dt^2/2)*M
           = (1 - gamma*dt)*h_k - dt*rho_max - (dt^2/2)*M

Define the discrete comparison sequence:
  beta_0^disc = h_0
  beta_{k+1}^disc = (1 - gamma*dt)*beta_k^disc - dt*rho_max - (dt^2/2)*M

CLAIM: h_k >= beta_k^disc for all k, PROVIDED dt <= 1/gamma (standard
forward-Euler stability condition -- without it (1-gamma*dt) could be
negative, breaking the monotone comparison induction below).
PROOF (induction): base case h_0 = beta_0^disc holds by definition.
Inductive step: assume h_k >= beta_k^disc. Since (1-gamma*dt) >= 0 (by
the dt<=1/gamma condition), the map x -> (1-gamma*dt)*x - dt*rho_max -
(dt^2/2)*M is non-decreasing in x, so
  h_{k+1} >= (1-gamma*dt)*h_k - dt*rho_max - (dt^2/2)*M
           >= (1-gamma*dt)*beta_k^disc - dt*rho_max - (dt^2/2)*M
           = beta_{k+1}^disc.  QED.

CLOSED FORM (linear recursion, standard):
  beta_k^disc = (1-gamma*dt)^k * h_0
                - [dt*rho_max + (dt^2/2)*M] * (1-(1-gamma*dt)^k) / (gamma*dt)

CONSISTENCY CHECK (did I derive a genuine discretization of Prop 1, not
an unrelated recursion?): as dt -> 0 with k*dt = t held fixed,
(1-gamma*dt)^k -> exp(-gamma*t) (standard limit) and the bracketed term's
dt^2 part vanishes relative to the dt part, so beta_k^disc -> beta(t) =
(h_0 + rho_max/gamma)*exp(-gamma*t) - rho_max/gamma, exactly Prop 1's
continuous floor. This is verified NUMERICALLY (not just algebraically)
in experiments/e9_discrete_time_bound.py before being trusted in the
manuscript -- see that file for the check and its result.

WHAT THIS DOES NOT FIX: this bound formalizes generic Euler truncation
error. It does NOT resolve the DIFFERENT discrete-time fragility
mechanism found on cart-pole (Sec 6/Sec "bftc design"): there, the
failure was a boundary-tight, ZERO-SLACK compensation law losing its
margin to discretization error entirely, which is a property of THAT
specific (exact worst-case-theta) control law, not a generic truncation-
error phenomenon this M-bounded analysis captures. Prop 6 gives a
genuine, formal discrete-time floor for the ADDITIVE-MARGIN design (the
one actually used throughout Sec 5, 9, 10), with an honest new
assumption (A8, bounded h'') and an honest scope note about what it does
NOT cover.

NATURAL CONNECTION TO "compute budget" (worth stating, not fully
developed as a separate contribution): dt itself consumes compute --
running the control loop at a finer dt requires more control-loop
executions per unit time, a form of compute expenditure distinct from
the RLS-tick budget tau already modeled. This gives a SECOND
compute-safety tradeoff axis (finer dt shrinks the (dt^2/2)*M erosion
term at the cost of more control-loop compute), which Prop 6 makes
visible but does not jointly optimize -- flagged as a natural extension,
not attempted here.

