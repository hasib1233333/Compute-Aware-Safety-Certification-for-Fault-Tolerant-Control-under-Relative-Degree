"""
testbeds/cartpole_ftc.py

Real safe-control-gym cartpole, NOT the hand-derived double integrator.
Differences that matter and are handled explicitly (not glossed over):

  - Dynamics are nonlinear and state-dependent: Lf_h, Lg_h are evaluated
    numerically at every step via the environment's own symbolic model
    (env.symbolic.fc_func), not assumed constant.
  - Safety constraint: h(x) = thetadot_max - |thetadot| (pole ANGULAR
    VELOCITY limit). Chosen because it is relative-degree-1 w.r.t. u
    (verified: g(x)[3] != 0 at generic states -- theta itself would be
    relative-degree-2 and is explicitly out of scope per notes/theory.md).
  - No artificial w_drift is added: the inverted pendulum's own open-loop
    instability provides genuine risk. The nominal controller is a PD
    restoring law u_des = -Kp*theta - Kd*thetadot; a weakened actuator
    under-delivers on this correction, which is the realistic FTC danger
    mode here (analogous to the double integrator's w_drift, but arising
    from the real dynamics rather than being hand-added).
  - Fault model: multiplicative actuator efficiency loss, u_actual =
    theta_true * u_cmd, identical fault model to the double integrator, so
    H1/H2 are being tested on the SAME hypothesis, different plant.
"""
import numpy as np
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.detector import RLSFaultDetector
from core.certificate import eps_eta_curve
from safe_control_gym.utils.registration import make

DISCRETE_TIME_SAFETY_FACTOR = 1.5


def get_Lf_Lg_xdot(sym, x):
    """
    h(x) = xdot_max - |xdot|  (cart VELOCITY limit -- a genuine real-world
    concern: staying within track/rail length limits, directly analogous
    to the double integrator's validated velocity-limit design). Chosen
    to replace an earlier thetadot-limit design that was found (empirically,
    with a full 200-step trace) to allow slow, constraint-respecting drift
    in theta itself, since bounding a derivative doesn't bound the
    underlying quantity -- see notes/theory.md and the session history for
    the full diagnosis. Cart velocity does not have this issue: it IS the
    quantity we want bounded, not a proxy for something else.
    hdot = -sign(xdot) * xddot,  xddot = f(x)[1] + g(x)[1]*u
    """
    f0 = np.array(sym.fc_func(x, [0.0])).flatten()
    f1 = np.array(sym.fc_func(x, [1.0])).flatten()
    g = f1 - f0
    xdot = x[1]
    s = np.sign(xdot) if abs(xdot) > 1e-6 else 1.0
    Lf_h = -s * f0[1]
    Lg_h = -s * g[1]
    return Lf_h, Lg_h, s


def get_Lf_Lg_thetadot(sym, x):
    """
    h(x) = thetadot_max - |thetadot| = thetadot_max - sign(thetadot)*thetadot
    hdot = -sign(thetadot) * thetaddot
    thetaddot = f(x)[3] + g(x)[3]*u   (state index 3 = thetadot's derivative slot)
    => Lf_h = -sign(thetadot) * f(x)[3],  Lg_h = -sign(thetadot) * g(x)[3]
    f(x), g(x) extracted numerically from the symbolic model (control-affine,
    verified in the exploration step: fc_func(x,u2)-fc_func(x,u1) is exactly
    constant in u for this system).
    """
    f0 = np.array(sym.fc_func(x, [0.0])).flatten()
    f1 = np.array(sym.fc_func(x, [1.0])).flatten()
    g = f1 - f0
    thetadot = x[3]
    s = np.sign(thetadot) if abs(thetadot) > 1e-6 else 1.0
    Lf_h = -s * f0[3]
    Lg_h = -s * g[3]
    return Lf_h, Lg_h, s


def run_strategy_cartpole(strategy, theta_true, xdot_max, gamma, delta_max,
                           sigma, eta, eps_trig, T_fixed_naive,
                           n_ticks_per_cycle, n_steps, K_lqr, u_lo, u_hi,
                           seed, init_theta=0.15, init_thetadot=0.0):
    assert strategy in ("no_ftc", "passive_ftc", "naive_active_ftc",
                         "bftc_binary", "bftc")
    env = make('cartpole', ctrl_freq=100, pyb_freq=100,
               init_state={'init_theta': init_theta, 'init_theta_dot': init_thetadot})
    obs, info = env.reset(seed=seed)
    sym = env.symbolic

    rng = np.random.default_rng(seed + 999983)
    det = RLSFaultDetector(1, forgetting=1.0, theta_init=1.0, p_init=100.0)
    from scipy.stats import norm as _norm
    z_precomp = np.sqrt(2 * np.log(2 * 1 / eta))  # sub-Gaussian Chernoff constant (m=1), corrected
    rho_max_cache = None  # computed online per-step since |Lg_h| varies

    h_hist = np.zeros(n_steps)
    thetadot_hist = np.zeros(n_steps)
    theta_hist = np.zeros(n_steps)
    triggered = False
    t_trigger = None
    dt = env.CTRL_TIMESTEP

    for k in range(n_steps):
        x = env.state.copy()
        theta, thetadot = x[2], x[3]
        h = xdot_max - abs(x[1])
        Lf_h, Lg_h, s = get_Lf_Lg_xdot(sym, x)

        u_des = float(-K_lqr @ x)   # nominal LQR restoring control

        if strategy == "no_ftc":
            theta_hat_eff, extra_margin = 1.0, 0.0
        elif strategy == "passive_ftc":
            rho_max_now = abs(Lg_h) * delta_max * u_hi
            theta_hat_eff, extra_margin = 1.0, rho_max_now
        elif strategy in ("naive_active_ftc", "bftc_binary"):
            theta_hat_eff = (1.0 - det.delta_hat[0]) if triggered else 1.0
            extra_margin = 0.0
        elif strategy == "bftc":
            theta_hat_point = 1.0 - det.delta_hat[0]
            if k == 0:
                eps_now = delta_max
            else:
                P_now = det.uncertainty.reshape(1, -1)
                eps_now = min(eps_eta_curve(P_now, sigma, eta, m=1,
                                             z_precomputed=z_precomp)[-1], delta_max)
            theta_hat_eff = theta_hat_point
            extra_margin = abs(Lg_h) * eps_now * u_hi

        # CBF-QP (scalar, closed form): Lf_h + Lg_h*theta_hat_eff*u >= -gamma*h + extra_margin
        # => coef*u >= rhs, coef = Lg_h*theta_hat_eff, rhs = -gamma*h + extra_margin - Lf_h
        coef = Lg_h * theta_hat_eff
        rhs = -gamma * h + extra_margin - Lf_h
        if abs(coef) < 1e-8:
            u_cmd = float(np.clip(u_des, u_lo, u_hi))
        elif coef > 0:
            lo_eff = max(u_lo, rhs / coef)
            u_cmd = float(np.clip(u_des, lo_eff, u_hi)) if lo_eff <= u_hi else u_hi
        else:
            hi_eff = min(u_hi, rhs / coef)
            u_cmd = float(np.clip(u_des, u_lo, hi_eff)) if hi_eff >= u_lo else u_lo

        u_actual = theta_true * u_cmd

        if strategy in ("naive_active_ftc", "bftc_binary", "bftc") and \
                (strategy == "bftc" or not triggered):
            regressor = Lg_h * u_cmd   # generalizes double-integrator's plain u_cmd
            for _ in range(n_ticks_per_cycle):
                y_true = theta_true * regressor
                y_obs = y_true + rng.normal(0, sigma)
                det.step(np.array([regressor]), np.array([y_obs]), n_ticks=1)

            if strategy == "naive_active_ftc" and not triggered:
                if (k + 1) * dt >= T_fixed_naive:
                    triggered, t_trigger = True, (k + 1) * dt
            elif strategy == "bftc_binary" and not triggered:
                P_now = det.uncertainty.reshape(1, -1)
                eps_k = eps_eta_curve(P_now, sigma, eta, m=1, z_precomputed=z_precomp)[-1]
                if eps_k <= eps_trig:
                    triggered, t_trigger = True, (k + 1) * dt

        obs, rew, done, info = env.step(np.array([u_actual]))
        theta_hist[k] = env.state[2]
        thetadot_hist[k] = env.state[3]
        h_hist[k] = xdot_max - abs(env.state[1])

    env.close()
    h_min = float(h_hist.min())
    return dict(
        strategy=strategy, theta_true=float(theta_true),
        h_min=h_min, safety_violation=bool(h_min < 0),
        t_trigger=float(t_trigger) if t_trigger is not None else None,
        mean_abs_theta=float(np.mean(np.abs(theta_hist))),
        final_abs_theta=float(abs(theta_hist[-1])),
        theta_hist=theta_hist, thetadot_hist=thetadot_hist, h_hist=h_hist,
    )
