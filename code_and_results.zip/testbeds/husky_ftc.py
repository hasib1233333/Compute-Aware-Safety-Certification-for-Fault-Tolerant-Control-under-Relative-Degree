"""
testbeds/husky_ftc.py

Real PyBullet Husky (4-wheel skid-steer ground robot), not a hand-derived
model. Empirical calibration (session history) found an essentially exact
constant-gain affine relationship between commanded wheel torque and base
longitudinal acceleration (slope = 0.2018, verified identical across three
different velocity states and two torque increments, well within numerical
noise) -- much simpler than cartpole's state-dependent nonlinear coupling,
so this testbed reuses the double-integrator's validated CBF structure
directly rather than needing per-step symbolic linearization.

Safety constraint: h(x) = v_max - vx (forward speed limit) -- directly the
safety-relevant quantity (track/collision speed limit), avoiding the
relative-degree mismatch found on cartpole.

Genuine risk mechanism: a constant external force (p.applyExternalForce,
simulating an incline or wind) pushes the robot toward v_max regardless of
command, exactly like the double integrator's w_drift, and for the same
reason -- a pure effectiveness-loss fault on a pure "push forward" task
cannot cause overshoot on its own (verified in the double-integrator
session history), so genuine danger requires something that demands ACTIVE
braking, which a weakened actuator then under-delivers.

Fault model: multiplicative effectiveness loss identical to all other
testbeds, u_actual = theta_true * u_cmd (torque command).
"""
import numpy as np
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import pybullet as p
import pybullet_data
from core.detector import RLSFaultDetector
from core.certificate import eps_eta_curve
from scipy.stats import norm as _norm

G_CAL = 0.2018     # calibrated torque->acceleration slope (empirical, session history)
WHEELS = [2, 3, 4, 5]


def make_husky_env(seed):
    cid = p.connect(p.DIRECT)
    p.setAdditionalSearchPath(pybullet_data.getDataPath())
    p.setGravity(0, 0, -9.8)
    dt = 0.01
    p.setTimeStep(dt)
    p.loadURDF('plane.urdf')
    husky = p.loadURDF('husky/husky.urdf', [0, 0, 0.15])
    for w in WHEELS:
        p.setJointMotorControl2(husky, w, p.VELOCITY_CONTROL, force=0)
    return husky, dt


def run_strategy_husky(strategy, theta_true, v_max, gamma, delta_max, sigma,
                        eta, eps_trig, T_fixed_naive, n_ticks_per_cycle,
                        n_steps, u_des_cmd, u_lo, u_hi, w_ext0, w_ramp_rate, seed):
    """
    w_ext0: initial disturbance magnitude (m/s^2 contribution).
    w_ramp_rate: rate at which the disturbance INCREASES over time
    (m/s^2 per second), simulating an ever-steepening downhill grade.
    Unlike a constant disturbance (found, with real measured drag data,
    to let the system reach a fault-severity-independent equilibrium
    velocity around 0.46-0.50 m/s -- see session history/paper Sec 7),
    a monotonically increasing disturbance cannot be equilibrated
    against: eventually w_ext(t) exceeds any FIXED actuator's braking
    capacity, creating genuine, escalating, inevitable risk rather than
    risk that depends on hitting a lucky combination of static
    parameters.
    """
    assert strategy in ("no_ftc", "passive_ftc", "naive_active_ftc",
                         "bftc_binary", "bftc")
    husky, dt = make_husky_env(seed)
    total_mass = sum(p.getDynamicsInfo(husky, link)[0] for link in [-1] + WHEELS)
    rng = np.random.default_rng(seed + 555001)
    det = RLSFaultDetector(1, forgetting=1.0, theta_init=1.0, p_init=100.0)
    z_precomp = np.sqrt(2 * np.log(2 * 1 / eta))  # sub-Gaussian Chernoff constant (m=1), corrected
    Lg_h = -G_CAL   # h = v_max - vx, hdot = -vxdot = -(w_ext_accel + G_CAL*u), so Lg_h=-G_CAL, Lf_h=-w_ext_accel(t)

    h_hist = np.zeros(n_steps)
    v_hist = np.zeros(n_steps)
    triggered = False
    t_trigger = None
    rho_max = abs(Lg_h) * delta_max * u_hi

    for k in range(n_steps):
        lin_vel, _ = p.getBaseVelocity(husky)
        vx = lin_vel[0]
        h = v_max - vx
        t_now = (k + 1) * dt
        w_ext_now = w_ext0 + w_ramp_rate * t_now   # ramping disturbance
        Lf_h = -w_ext_now

        if strategy == "no_ftc":
            theta_hat_eff, extra_margin = 1.0, 0.0
        elif strategy == "passive_ftc":
            theta_hat_eff, extra_margin = 1.0, rho_max
        elif strategy in ("naive_active_ftc", "bftc_binary"):
            theta_hat_eff = (1.0 - det.delta_hat[0]) if triggered else 1.0
            extra_margin = 0.0
        elif strategy == "bftc":
            theta_hat_point = 1.0 - det.delta_hat[0]
            if k == 0:
                eps_now = delta_max
            else:
                P_now = det.uncertainty.reshape(1, -1)
                eps_now = min(eps_eta_curve(P_now, sigma, eta, m=1,
                                             z_precomputed=z_precomp)[-1], delta_max)
            theta_hat_eff = theta_hat_point
            extra_margin = abs(Lg_h) * eps_now * u_hi

        coef = Lg_h * theta_hat_eff
        rhs = -gamma * h + extra_margin - Lf_h
        if abs(coef) < 1e-8:
            u_cmd = float(np.clip(u_des_cmd, u_lo, u_hi))
        elif coef > 0:
            lo_eff = max(u_lo, rhs / coef)
            u_cmd = float(np.clip(u_des_cmd, lo_eff, u_hi)) if lo_eff <= u_hi else u_hi
        else:
            hi_eff = min(u_hi, rhs / coef)
            u_cmd = float(np.clip(u_des_cmd, u_lo, hi_eff)) if hi_eff >= u_lo else u_lo

        u_actual = theta_true * u_cmd

        if strategy in ("naive_active_ftc", "bftc_binary", "bftc") and \
                (strategy == "bftc" or not triggered):
            for _ in range(n_ticks_per_cycle):
                y_obs = theta_true * u_cmd + rng.normal(0, sigma)
                det.step(np.array([u_cmd]), np.array([y_obs]), n_ticks=1)
            if strategy == "naive_active_ftc" and not triggered:
                if (k + 1) * dt >= T_fixed_naive:
                    triggered, t_trigger = True, (k + 1) * dt
            elif strategy == "bftc_binary" and not triggered:
                P_now = det.uncertainty.reshape(1, -1)
                eps_k = eps_eta_curve(P_now, sigma, eta, m=1, z_precomputed=z_precomp)[-1]
                if eps_k <= eps_trig:
                    triggered, t_trigger = True, (k + 1) * dt

        # apply: actuator torque (faulted) + TIME-VARYING external disturbance force
        for w in WHEELS:
            p.setJointMotorControl2(husky, w, p.TORQUE_CONTROL, force=u_actual)
        p.applyExternalForce(husky, -1, forceObj=[w_ext_now * total_mass, 0, 0],
                              posObj=[0, 0, 0], flags=p.LINK_FRAME)
        p.stepSimulation()

        lin_vel2, _ = p.getBaseVelocity(husky)
        h_hist[k] = v_max - lin_vel2[0]
        v_hist[k] = lin_vel2[0]

    p.disconnect()
    h_min = float(h_hist.min())
    return dict(strategy=strategy, theta_true=float(theta_true), h_min=h_min,
                safety_violation=bool(h_min < 0),
                t_trigger=float(t_trigger) if t_trigger is not None else None,
                mean_v=float(np.mean(v_hist)), final_v=float(v_hist[-1]))
