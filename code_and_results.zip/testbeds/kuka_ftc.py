"""
testbeds/kuka_ftc.py

Real PyBullet KUKA IIWA (7-DOF, kuka_iiwa/model.urdf), one joint (joint
index 1, the main shoulder-pitch joint that carries the most gravity
torque) actuated and monitored; all other joints locked via strong
position control so the isolated joint's dynamics are clean and
control-affine in its own torque (verified empirically: slope=0.2983
constant across three poses and three torque levels, session history).

Deliberately DIFFERENT risk mechanism from Husky (testbeds/husky_ftc.py):
gravity pulls on the joint regardless of actuator health -- the danger
source is structurally independent of the actuator being faulted, unlike
Husky's task where the SAME wheels provide both the risk-causing push and
the safety-providing brake, which was found (session history) to create
an inherent fail-safe bias that made genuine risk very hard to create.
Gravity has no such symmetry: a weak joint motor is worse at holding the
arm up AND worse at slowing its fall, both in the SAME (dangerous)
direction, matching the double integrator's validated w_drift design
rather than Husky's problematic shared-channel design.

Safety constraint: h(x) = qdot_max - |qdot| (joint angular velocity
limit), genuinely relative-degree-1 w.r.t. joint torque (torque directly
sets joint acceleration = qdot's derivative) -- avoiding cart-pole's
relative-degree mismatch (Sec 6 of the paper) by construction, per the
review roadmap's explicit guidance.

Lf_h computed analytically via PyBullet's calculateInverseDynamics with
zero target acceleration (verified self-consistent with direct
step-based measurement to within simulation precision) -- no
finite-difference stepping tricks needed, unlike an earlier (abandoned)
approach.
"""
import numpy as np
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import pybullet as p
import pybullet_data
from core.detector import RLSFaultDetector
from core.certificate import eps_eta_curve
from scipy.stats import norm as _norm

JOINT_IDX = 1
G_CAL = 0.2983  # calibrated torque->joint-acceleration slope (session history)
LOCK_FORCE = 500


def make_kuka_env(seed, q1_init):
    p.connect(p.DIRECT)
    p.setAdditionalSearchPath(pybullet_data.getDataPath())
    p.setGravity(0, 0, -9.8)
    dt = 0.01
    p.setTimeStep(dt)
    kuka = p.loadURDF('kuka_iiwa/model.urdf', useFixedBase=True)
    n = p.getNumJoints(kuka)
    p.resetJointState(kuka, JOINT_IDX, targetValue=q1_init, targetVelocity=0.0)
    for i in range(n):
        if i != JOINT_IDX:
            p.setJointMotorControl2(kuka, i, p.POSITION_CONTROL, targetPosition=0.0, force=LOCK_FORCE)
        else:
            p.setJointMotorControl2(kuka, i, p.VELOCITY_CONTROL, force=0)
    return kuka, dt, n


def get_Lf_Lg(kuka, n, qdot):
    q_all = [p.getJointState(kuka, i)[0] for i in range(n)]
    qd_all = [p.getJointState(kuka, i)[1] for i in range(n)]
    tau_gc = p.calculateInverseDynamics(kuka, q_all, qd_all, [0.0] * n)
    f_accel = -G_CAL * tau_gc[JOINT_IDX]  # accel at u=0
    s = np.sign(qdot) if abs(qdot) > 1e-6 else 1.0
    Lf_h = -s * f_accel
    Lg_h = -s * G_CAL
    return Lf_h, Lg_h, s


def run_strategy_kuka(strategy, theta_true, qdot_max, gamma, delta_max,
                       sigma, eta, eps_trig, T_fixed_naive,
                       n_ticks_per_cycle, n_steps, u_des_cmd, u_lo, u_hi,
                       seed, q1_init=-1.3):
    assert strategy in ("no_ftc", "passive_ftc", "naive_active_ftc",
                         "bftc_binary", "bftc")
    kuka, dt, n = make_kuka_env(seed, q1_init)
    rng = np.random.default_rng(seed + 777001)
    det = RLSFaultDetector(1, forgetting=1.0, theta_init=1.0, p_init=100.0)
    z_precomp = np.sqrt(2 * np.log(2 * 1 / eta))  # sub-Gaussian Chernoff constant (m=1), corrected

    h_hist = np.zeros(n_steps)
    q_hist = np.zeros(n_steps)
    qdot_hist = np.zeros(n_steps)
    triggered = False
    t_trigger = None

    for k in range(n_steps):
        qdot = p.getJointState(kuka, JOINT_IDX)[1]
        h = qdot_max - abs(qdot)
        Lf_h, Lg_h, s = get_Lf_Lg(kuka, n, qdot)

        if strategy == "no_ftc":
            theta_hat_eff, extra_margin = 1.0, 0.0
        elif strategy == "passive_ftc":
            rho_max_now = abs(Lg_h) * delta_max * u_hi
            theta_hat_eff, extra_margin = 1.0, rho_max_now
        elif strategy in ("naive_active_ftc", "bftc_binary"):
            theta_hat_eff = (1.0 - det.delta_hat[0]) if triggered else 1.0
            extra_margin = 0.0
        elif strategy == "bftc":
            theta_hat_point = 1.0 - det.delta_hat[0]
            if k == 0:
                eps_now = delta_max
            else:
                P_now = det.uncertainty.reshape(1, -1)
                eps_now = min(eps_eta_curve(P_now, sigma, eta, m=1,
                                             z_precomputed=z_precomp)[-1], delta_max)
            theta_hat_eff = theta_hat_point
            extra_margin = abs(Lg_h) * eps_now * u_hi

        coef = Lg_h * theta_hat_eff
        rhs = -gamma * h + extra_margin - Lf_h
        if abs(coef) < 1e-8:
            u_cmd = float(np.clip(u_des_cmd, u_lo, u_hi))
        elif coef > 0:
            lo_eff = max(u_lo, rhs / coef)
            u_cmd = float(np.clip(u_des_cmd, lo_eff, u_hi)) if lo_eff <= u_hi else u_hi
        else:
            hi_eff = min(u_hi, rhs / coef)
            u_cmd = float(np.clip(u_des_cmd, u_lo, hi_eff)) if hi_eff >= u_lo else u_lo

        u_actual = theta_true * u_cmd

        if strategy in ("naive_active_ftc", "bftc_binary", "bftc") and \
                (strategy == "bftc" or not triggered):
            regressor = Lg_h * u_cmd
            for _ in range(n_ticks_per_cycle):
                y_true = theta_true * regressor
                y_obs = y_true + rng.normal(0, sigma)
                det.step(np.array([regressor]), np.array([y_obs]), n_ticks=1)
            if strategy == "naive_active_ftc" and not triggered:
                if (k + 1) * dt >= T_fixed_naive:
                    triggered, t_trigger = True, (k + 1) * dt
            elif strategy == "bftc_binary" and not triggered:
                P_now = det.uncertainty.reshape(1, -1)
                eps_k = eps_eta_curve(P_now, sigma, eta, m=1, z_precomputed=z_precomp)[-1]
                if eps_k <= eps_trig:
                    triggered, t_trigger = True, (k + 1) * dt

        p.setJointMotorControl2(kuka, JOINT_IDX, p.TORQUE_CONTROL, force=u_actual)
        p.stepSimulation()

        q_hist[k] = p.getJointState(kuka, JOINT_IDX)[0]
        qdot_hist[k] = p.getJointState(kuka, JOINT_IDX)[1]
        h_hist[k] = qdot_max - abs(qdot_hist[k])

    p.disconnect()
    h_min = float(h_hist.min())
    return dict(strategy=strategy, theta_true=float(theta_true), h_min=h_min,
                safety_violation=bool(h_min < 0),
                t_trigger=float(t_trigger) if t_trigger is not None else None,
                max_abs_q=float(np.max(np.abs(q_hist))),
                mean_qdot=float(np.mean(qdot_hist)))
