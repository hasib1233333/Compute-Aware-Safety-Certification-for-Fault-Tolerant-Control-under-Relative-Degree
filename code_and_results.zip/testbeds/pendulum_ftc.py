"""
testbeds/pendulum_ftc.py

A minimal single pendulum, built from scratch (testbeds/simple_pendulum.urdf)
as a third, structurally independent benchmark. Chosen deliberately as the
canonical nonlinear-control test system, and because it is the purest
form of the pattern already validated on the KUKA manipulator
(Section 10): gravity pulls on the link regardless of actuator health,
giving the same risk-independent-of-actuator-fault structure that made
both the double integrator and the manipulator work cleanly -- unlike
Husky's shared push/brake wheel channel (Section 7), which was found,
across four separate attempts, to create an inherent fail-safe bias no
disturbance magnitude could overcome.

Affine structure verified empirically before use (slope=2.98942 N*m^-1*rad*s^-2,
constant across three poses and three torque levels). Feasibility computed
analytically before running any comparison (minimum u_hi=12.25 for the
worst-case fault bound; u_hi=20 used, comfortable margin) -- avoiding the
repeated "discover infeasibility empirically after confusing results"
pattern from earlier testbeds.

Safety constraint: h(x) = qdot_max - |qdot| (joint angular velocity
limit), genuinely relative-degree-one w.r.t. torque.
"""
import numpy as np
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import pybullet as p
from core.detector import RLSFaultDetector
from core.certificate import eps_eta_curve
from scipy.stats import norm as _norm

G_CAL = 2.98942  # calibrated torque->acceleration slope (verified, session history)
URDF_PATH = os.path.join(os.path.dirname(__file__), "simple_pendulum.urdf")


def make_pendulum_env(seed, q_init):
    p.connect(p.DIRECT)
    p.setGravity(0, 0, -9.8)
    dt = 0.01
    p.setTimeStep(dt)
    pend = p.loadURDF(URDF_PATH, useFixedBase=True)
    p.setJointMotorControl2(pend, 0, p.VELOCITY_CONTROL, force=0)
    p.resetJointState(pend, 0, targetValue=q_init, targetVelocity=0.0)
    return pend, dt


def get_Lf_Lg(pend, qdot):
    q = p.getJointState(pend, 0)[0]
    qd = p.getJointState(pend, 0)[1]
    tau_gc = p.calculateInverseDynamics(pend, [q], [qd], [0.0])[0]
    f_accel = -G_CAL * tau_gc
    s = np.sign(qdot) if abs(qdot) > 1e-6 else 1.0
    Lf_h = -s * f_accel
    Lg_h = -s * G_CAL
    return Lf_h, Lg_h, s


def run_strategy_pendulum(strategy, theta_true, qdot_max, gamma, delta_max,
                           sigma, eta, eps_trig, T_fixed_naive,
                           n_ticks_per_cycle, n_steps, u_des_cmd, u_lo, u_hi,
                           seed, q_init=-1.4):
    assert strategy in ("no_ftc", "passive_ftc", "naive_active_ftc",
                         "bftc_binary", "bftc")
    pend, dt = make_pendulum_env(seed, q_init)
    rng = np.random.default_rng(seed + 888001)
    det = RLSFaultDetector(1, forgetting=1.0, theta_init=1.0, p_init=100.0)
    z_precomp = np.sqrt(2 * np.log(2 * 1 / eta))  # sub-Gaussian Chernoff constant (m=1), corrected

    h_hist = np.zeros(n_steps)
    q_hist = np.zeros(n_steps)
    qdot_hist = np.zeros(n_steps)
    triggered = False
    t_trigger = None

    for k in range(n_steps):
        qdot = p.getJointState(pend, 0)[1]
        h = qdot_max - abs(qdot)
        Lf_h, Lg_h, s = get_Lf_Lg(pend, qdot)

        if strategy == "no_ftc":
            theta_hat_eff, extra_margin = 1.0, 0.0
        elif strategy == "passive_ftc":
            rho_max_now = abs(Lg_h) * delta_max * u_hi
            theta_hat_eff, extra_margin = 1.0, rho_max_now
        elif strategy in ("naive_active_ftc", "bftc_binary"):
            theta_hat_eff = (1.0 - det.delta_hat[0]) if triggered else 1.0
            extra_margin = 0.0
        elif strategy == "bftc":
            theta_hat_point = 1.0 - det.delta_hat[0]
            if k == 0:
                eps_now = delta_max
            else:
                P_now = det.uncertainty.reshape(1, -1)
                eps_now = min(eps_eta_curve(P_now, sigma, eta, m=1,
                                             z_precomputed=z_precomp)[-1], delta_max)
            theta_hat_eff = theta_hat_point
            extra_margin = abs(Lg_h) * eps_now * u_hi

        coef = Lg_h * theta_hat_eff
        rhs = -gamma * h + extra_margin - Lf_h
        if abs(coef) < 1e-8:
            u_cmd = float(np.clip(u_des_cmd, u_lo, u_hi))
        elif coef > 0:
            lo_eff = max(u_lo, rhs / coef)
            u_cmd = float(np.clip(u_des_cmd, lo_eff, u_hi)) if lo_eff <= u_hi else u_hi
        else:
            hi_eff = min(u_hi, rhs / coef)
            u_cmd = float(np.clip(u_des_cmd, u_lo, hi_eff)) if hi_eff >= u_lo else u_lo

        u_actual = theta_true * u_cmd

        if strategy in ("naive_active_ftc", "bftc_binary", "bftc") and \
                (strategy == "bftc" or not triggered):
            regressor = Lg_h * u_cmd
            for _ in range(n_ticks_per_cycle):
                y_obs = theta_true * regressor + rng.normal(0, sigma)
                det.step(np.array([regressor]), np.array([y_obs]), n_ticks=1)
            if strategy == "naive_active_ftc" and not triggered:
                if (k + 1) * dt >= T_fixed_naive:
                    triggered, t_trigger = True, (k + 1) * dt
            elif strategy == "bftc_binary" and not triggered:
                P_now = det.uncertainty.reshape(1, -1)
                eps_k = eps_eta_curve(P_now, sigma, eta, m=1, z_precomputed=z_precomp)[-1]
                if eps_k <= eps_trig:
                    triggered, t_trigger = True, (k + 1) * dt

        p.setJointMotorControl2(pend, 0, p.TORQUE_CONTROL, force=u_actual)
        p.stepSimulation()

        q_hist[k] = p.getJointState(pend, 0)[0]
        qdot_hist[k] = p.getJointState(pend, 0)[1]
        h_hist[k] = qdot_max - abs(qdot_hist[k])

    p.disconnect()
    h_min = float(h_hist.min())
    return dict(strategy=strategy, theta_true=float(theta_true), h_min=h_min,
                safety_violation=bool(h_min < 0),
                t_trigger=float(t_trigger) if t_trigger is not None else None,
                max_abs_q=float(np.max(np.abs(q_hist))),
                mean_qdot=float(np.mean(qdot_hist)))
