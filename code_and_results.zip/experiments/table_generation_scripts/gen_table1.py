import json

with open('results/e3_double_integrator_comparison.json') as f:
    d = json.load(f)

budgets = [1, 2, 3, 5, 8, 10, 15, 25, 40]
strategies = ['no_ftc', 'passive_ftc', 'naive_active_ftc', 'bftc_binary', 'bftc']
labels = {'no_ftc': 'No-FTC', 'passive_ftc': 'Passive-FTC',
          'naive_active_ftc': 'Naive Active-FTC',
          'bftc_binary': 'BFTC (binary)', 'bftc': 'BFTC (proposed)'}

backslash_backslash = chr(92) + chr(92)

lines = []
lines.append(r'\begin{tabular}{lcccccccccc}')
lines.append(r'\toprule')
lines.append('Strategy & ' + ' & '.join(str(b) for b in budgets) + ' ' + backslash_backslash)
lines.append(r'\midrule')
lines.append(r'\multicolumn{10}{l}{\textit{Safety violation rate}} ' + backslash_backslash)
for s in strategies:
    vals = [d[f'{s}__budget_{b}']['violation_rate'] for b in budgets]
    lines.append(labels[s] + ' & ' + ' & '.join(f'{v:.3f}' for v in vals) + ' ' + backslash_backslash)
lines.append(r'\midrule')
lines.append(r'\multicolumn{10}{l}{\textit{Task performance (mean velocity fraction)}} ' + backslash_backslash)
for s in strategies:
    vals = [d[f'{s}__budget_{b}']['mean_perf'] for b in budgets]
    lines.append(labels[s] + ' & ' + ' & '.join(f'{v:.3f}' for v in vals) + ' ' + backslash_backslash)
lines.append(r'\bottomrule')
lines.append(r'\end{tabular}')

with open('manuscript/tables/table1.tex', 'w') as f:
    f.write('\n'.join(lines))

print('\n'.join(lines))
