import json

bs = chr(92)

with open('results/e5_multiactuator_scalability.json') as f:
    d = json.load(f)

m_vals = [1, 4, 8, 16]
strats = ['no_ftc', 'passive_ftc', 'bftc']
labels = {'no_ftc': 'No-FTC', 'passive_ftc': 'Passive-FTC', 'bftc': 'BFTC (proposed)'}

lines = []
lines.append(r'\begin{tabular}{lcccc}')
lines.append(r'\toprule')
lines.append('Strategy & ' + ' & '.join('m=' + str(m) for m in m_vals) + ' ' + bs + bs)
lines.append(r'\midrule')
lines.append(r'\multicolumn{5}{l}{\textit{Safety violation rate}} ' + bs + bs)
for s in strats:
    vals = [d['m_' + str(m) + '__' + s]['violation_rate'] for m in m_vals]
    lines.append(labels[s] + ' & ' + ' & '.join('{:.3f}'.format(v) for v in vals) + ' ' + bs + bs)
lines.append(r'\midrule')
lines.append(r'\multicolumn{5}{l}{\textit{Task performance}} ' + bs + bs)
for s in strats:
    vals = [d['m_' + str(m) + '__' + s]['mean_perf'] for m in m_vals]
    lines.append(labels[s] + ' & ' + ' & '.join('{:.3f}'.format(v) for v in vals) + ' ' + bs + bs)
lines.append(r'\midrule')
lines.append(r'\multicolumn{5}{l}{\textit{Wall-clock cost (ms/trial, BFTC only)}} ' + bs + bs)
vals = [d['m_' + str(m) + '__bftc']['wall_clock_per_trial_ms'] for m in m_vals]
lines.append('BFTC & ' + ' & '.join('{:.1f}'.format(v) for v in vals) + ' ' + bs + bs)
lines.append(r'\bottomrule')
lines.append(r'\end{tabular}')

out = '\n'.join(lines)
with open('manuscript/tables/table6.tex', 'w') as f:
    f.write(out)
print(out)
