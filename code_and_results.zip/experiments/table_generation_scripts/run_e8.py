import sys, os
sys.path.insert(0, '.')
import numpy as np
import json
from testbeds.pendulum_ftc import run_strategy_pendulum

COMMON = dict(qdot_max=1.0, gamma=1.5, delta_max=0.6, sigma=1.0, eta=0.1,
              eps_trig=0.02, T_fixed_naive=0.3, n_ticks_per_cycle=8, n_steps=150,
              u_des_cmd=0.0, u_lo=-20.0, u_hi=20.0, q_init=-1.4)
STRATS = ["no_ftc", "passive_ftc", "naive_active_ftc", "bftc_binary", "bftc"]

out_path = "results/e8_pendulum_comparison.json"
results = {}
if os.path.exists(out_path):
    with open(out_path) as f:
        results = json.load(f)

strat = os.environ.get("E8_STRAT")
n_trials = int(os.environ.get("E8_NTRIALS", "40"))
strat_list = [strat] if strat else STRATS

for s in strat_list:
    rng = np.random.default_rng(9000)
    n_viol = 0
    h_mins = []
    for trial in range(n_trials):
        theta_true = rng.uniform(1 - COMMON["delta_max"], 1.0)
        r = run_strategy_pendulum(s, theta_true=theta_true, seed=9000 + trial, **COMMON)
        n_viol += r["safety_violation"]
        h_mins.append(r["h_min"])
    results[s] = dict(n_trials=n_trials, n_violations=n_viol,
                       violation_rate=n_viol / n_trials,
                       mean_h_min=float(np.mean(h_mins)))
    print(f"{s}: {n_viol}/{n_trials} violations, mean_h_min={np.mean(h_mins):.3f}")

with open(out_path, "w") as f:
    json.dump(results, f, indent=2)
print("saved")
