import json

bs = chr(92)

with open('results/e4_statistics_sensitivity_ablation.json') as f:
    d = json.load(f)

# Table 2: paired statistical significance
lines = []
lines.append(r'\begin{tabular}{lcccc}')
lines.append(r'\toprule')
lines.append(r'Comparison (vs.\ BFTC) & Budget & McNemar $p$ & $n_{01}$/$n_{10}$ & Cohen $d_z$ (perf.) ' + bs + bs)
lines.append(r'\midrule')
name_map = {'no_ftc': 'No-FTC', 'passive_ftc': 'Passive-FTC',
            'naive_active_ftc': 'Naive Active-FTC', 'bftc_binary': 'BFTC (binary)'}
for label, budget_str in [('low_budget_1', '1'), ('high_budget_25', '25')]:
    for s in ['no_ftc', 'passive_ftc', 'naive_active_ftc', 'bftc_binary']:
        st = d['paired_statistics'][label][f'bftc_vs_{s}']
        p = st['mcnemar']['p_value']
        p_str = f'{p:.2e}' if p < 0.001 else f'{p:.4f}'
        n01, n10 = st['mcnemar']['n01'], st['mcnemar']['n10']
        dz = st['cohens_dz']
        lines.append(f"{name_map[s]} & {budget_str} & {p_str} & {n01}/{n10} & {dz:.3f} " + bs + bs)
lines.append(r'\bottomrule')
lines.append(r'\end{tabular}')
with open('manuscript/tables/table2.tex', 'w') as f:
    f.write('\n'.join(lines))
print('table2.tex (statistics) written')

# Table 3: Bonferroni ablation
n = d['bonferroni_ablation']['n_trials']
vw = d['bonferroni_ablation']['viol_with']
vwo = d['bonferroni_ablation']['viol_without']
lines = []
lines.append(r'\begin{tabular}{lcc}')
lines.append(r'\toprule')
lines.append(r'Confidence correction & Violations & Rate ' + bs + bs)
lines.append(r'\midrule')
lines.append(f'With Bonferroni ($z=\\Phi^{{-1}}(1-\\eta/2)$) & {vw}/{n} & {vw/n:.3f} ' + bs + bs)
lines.append(f'Without ($z=\\Phi^{{-1}}(1-\\eta)$) & {vwo}/{n} & {vwo/n:.3f} ' + bs + bs)
lines.append(r'\bottomrule')
lines.append(r'\end{tabular}')
with open('manuscript/tables/table3.tex', 'w') as f:
    f.write('\n'.join(lines))
print('table3.tex (Bonferroni ablation) written')

# Table 4: sensitivity summary (fault severity)
lines = []
lines.append(r'\begin{tabular}{lccccc}')
lines.append(r'\toprule')
lines.append(r'Strategy & $\delta_{max}=0.3$ & $0.5$ & $0.7$ & $0.85$ ' + bs + bs)
lines.append(r'\midrule')
strat_names = {'no_ftc': 'No-FTC', 'passive_ftc': 'Passive-FTC',
               'naive_active_ftc': 'Naive Active-FTC', 'bftc_binary': 'BFTC (binary)',
               'bftc': 'BFTC (proposed)'}
for s in ['no_ftc', 'passive_ftc', 'naive_active_ftc', 'bftc_binary', 'bftc']:
    vals = [d['sensitivity_fault_severity'][f'delta_max_{v}__{s}']['violation_rate']
            for v in [0.3, 0.5, 0.7, 0.85]]
    lines.append(strat_names[s] + ' & ' + ' & '.join(f'{v:.3f}' for v in vals) + ' ' + bs + bs)
lines.append(r'\bottomrule')
lines.append(r'\end{tabular}')
with open('manuscript/tables/table4.tex', 'w') as f:
    f.write('\n'.join(lines))
print('table4.tex (fault severity sensitivity) written')

# Table: computational cost
cost = d['computational_cost']
lines = []
lines.append(r'\begin{tabular}{lcccccc}')
lines.append(r'\toprule')
lines.append(r'Budget (ticks/cycle) & 1 & 5 & 10 & 25 & 40 & per-tick ($\mu$s) ' + bs + bs)
lines.append(r'\midrule')
budgets = ['1', '5', '10', '25', '40']
times_ms = [cost['per_trial_seconds_by_budget'][b] * 1000 for b in budgets]
lines.append('Wall-clock/trial (ms) & ' + ' & '.join(f'{t:.2f}' for t in times_ms) +
              f" & {cost['per_tick_microseconds']:.2f} " + bs + bs)
lines.append(r'\bottomrule')
lines.append(r'\end{tabular}')
with open('manuscript/tables/table5.tex', 'w') as f:
    f.write('\n'.join(lines))
print('table5.tex (computational cost) written')
