import json

bs = chr(92)

with open('results/e4_statistics_sensitivity_ablation.json') as f:
    d = json.load(f)

n = d['bonferroni_ablation']['n_trials']
vw = d['bonferroni_ablation']['viol_with']
vwo = d['bonferroni_ablation']['viol_without']

lines = []
lines.append(r'\begin{tabular}{lcc}')
lines.append(r'\toprule')
lines.append(r'Confidence correction & Violations & Rate ' + bs + bs)
lines.append(r'\midrule')

row1 = 'With two-sided correction ($z=' + bs + r'sqrt{2' + bs + r'log(2/' + bs + r'eta)}$) & '
row1 += str(vw) + '/' + str(n) + ' & ' + '{:.3f}'.format(vw / n) + ' ' + bs + bs
lines.append(row1)

row2 = 'Without ($z=' + bs + r'sqrt{2' + bs + r'log(1/' + bs + r'eta)}$) & '
row2 += str(vwo) + '/' + str(n) + ' & ' + '{:.3f}'.format(vwo / n) + ' ' + bs + bs
lines.append(row2)

lines.append(r'\bottomrule')
lines.append(r'\end{tabular}')

out = '\n'.join(lines)
with open('manuscript/tables/table3.tex', 'w') as f:
    f.write(out)
print(out)
