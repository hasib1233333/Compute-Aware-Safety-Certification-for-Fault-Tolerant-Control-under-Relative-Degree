"""
e1_certificate_validation_double_integrator.py

Simplest possible system where Prop. 1 (notes/theory.md Sec. 5) can be
checked completely by hand:

  State x = [p, v].  xdot = [v, u_actual],  u_actual = theta * u_cmd
  (m=1 actuator, theta in (0,1] unknown constant fault, present from t=0,
   NOT yet estimated -- this experiment tests ONLY the "before detection"
   safety-degradation bound, Sec. 4-5. Detector integration is e2.)

  h(x) = v_max - v   =>  Lf_h = 0, Lg_h = -1 (exactly, no approximation).
  Nominal pi_0(x): constant desired accel pushing v upward (worst case for
  this h), u_des = +a_push, then passed through the (unfaulted-assumption)
  CBF-QP filter so that IF theta=1 the filter would keep h>=0 exactly.

  rho_max for this system is available in EXACT closed form (no numerical
  estimation needed), unlike the general case in theory.md:
    rho_max = |Lg_h| * delta_max * |pi_0_bound| = 1 * delta_max * u_hi
  (since Lg_h = -1 exactly and u is clipped to [u_lo, u_hi], pi_0 after
  the QP filter is itself bounded by u_hi in magnitude).

This experiment: for many (theta, x0) pairs, simulate the TRUE (faulted)
system under the controller that (wrongly) assumes theta=1, record the
realized min h(t) over a fixed horizon, and check it against the Prop. 1
floor beta(t). Since theta is deterministic here (no detector noise), Prop
1's bound should hold with NO exceptions (eta=0 in this restricted
setting) -- this isolates whether the comparison-lemma math itself
(Sec 4-5) is correctly implemented, before adding detector randomness.
"""
import numpy as np
import json
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.cbf_filter import CBFQPFilter


def simulate(theta_true, delta_max, v_max, a_push, u_lo, u_hi, gamma,
             dt, T, v0=0.0, p0=0.0):
    filt = CBFQPFilter(m=1, u_lo=[u_lo], u_hi=[u_hi], gamma=gamma)
    n_steps = int(T / dt)
    p, v = p0, v0
    h_hist = np.zeros(n_steps)
    t_hist = np.zeros(n_steps)
    for k in range(n_steps):
        h = v_max - v
        Lf_h = 0.0
        Lg_h = np.array([-1.0])
        u_des = np.array([a_push])
        # controller assumes theta_hat=1 (fault NOT yet known) -- this is
        # exactly the "before detection" worst case from theory.md Sec 4.
        u_cmd, feasible = filt.filter(u_des, h, Lf_h, Lg_h, theta_hat=np.array([1.0]))
        u_actual = theta_true * u_cmd[0]   # TRUE dynamics use the real theta
        v = v + dt * u_actual
        p = p + dt * v
        h_hist[k] = v_max - v
        t_hist[k] = (k + 1) * dt
    return t_hist, h_hist


def prop1_floor(t, h0, rho_max, gamma):
    return (h0 + rho_max / gamma) * np.exp(-gamma * t) - rho_max / gamma


def main():
    rng = np.random.default_rng(42)
    v_max = 5.0
    a_push = 3.0          # nominal push toward v_max (worst-case direction)
    u_lo, u_hi = -3.0, 3.0
    gamma = 1.5
    dt = 0.01
    T = 3.0
    delta_max = 0.9        # design bound: actuator can lose up to 90% effectiveness
    rho_max = 1.0 * delta_max * u_hi  # exact, as derived above (|Lg_h|=1)

    n_trials = 300
    violations = []
    tightness = []   # observed_min_h - predicted_floor_min, should be >= 0

    all_results = []
    for trial in range(n_trials):
        theta_true = rng.uniform(1.0 - delta_max, 1.0)   # theta in [0.1, 1.0]
        v0 = rng.uniform(0.0, v_max * 0.6)
        h0 = v_max - v0

        t_hist, h_hist = simulate(theta_true, delta_max, v_max, a_push,
                                   u_lo, u_hi, gamma, dt, T, v0=v0)
        floor = prop1_floor(t_hist, h0, rho_max, gamma)

        gap = h_hist - floor   # must be >= 0 everywhere if theory holds
        min_gap = gap.min()
        tightness.append(float(min_gap))
        if min_gap < -1e-6:
            violations.append(dict(trial=trial, theta_true=float(theta_true),
                                    v0=float(v0), min_gap=float(min_gap)))
        all_results.append(dict(theta_true=float(theta_true), v0=float(v0),
                                 min_gap=float(min_gap),
                                 min_h_observed=float(h_hist.min())))

    n_viol = len(violations)
    print(f"Trials: {n_trials}")
    print(f"Prop. 1 floor violations (observed h < predicted floor): {n_viol}")
    if n_viol > 0:
        print("  *** THEORY VIOLATED in these cases (reporting honestly): ***")
        for v in violations[:10]:
            print("   ", v)
    print(f"Tightness stats (observed_h - predicted_floor, min over each "
          f"trajectory): mean={np.mean(tightness):.4f}, "
          f"median={np.median(tightness):.4f}, min={np.min(tightness):.4f}, "
          f"max={np.max(tightness):.4f}")
    print("(mean/median large and positive relative to min=0 boundary means "
          "the bound is CORRECT but conservative -- expected, since Sec.4 "
          "uses a worst-case bound assuming the fault is maximally adversarial "
          "in direction at every instant, which a fixed random theta_true "
          "is not.)")

    os.makedirs("/home/claude/ftc_paper/results", exist_ok=True)
    with open("/home/claude/ftc_paper/results/e1_certificate_validation.json", "w") as f:
        json.dump(dict(n_trials=n_trials, n_violations=n_viol,
                        violations=violations,
                        tightness_mean=float(np.mean(tightness)),
                        tightness_median=float(np.median(tightness)),
                        tightness_min=float(np.min(tightness)),
                        all_results=all_results,
                        params=dict(v_max=v_max, a_push=a_push, u_lo=u_lo,
                                    u_hi=u_hi, gamma=gamma, dt=dt, T=T,
                                    delta_max=delta_max, rho_max=rho_max)),
                  f, indent=2)
    print("\nSaved to results/e1_certificate_validation.json")


if __name__ == "__main__":
    main()
