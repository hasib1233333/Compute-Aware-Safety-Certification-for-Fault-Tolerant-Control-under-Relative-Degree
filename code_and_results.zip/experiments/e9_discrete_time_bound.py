"""
e9_discrete_time_bound.py

Verifies Prop 6 (notes/theory.md) numerically before it is trusted in the
manuscript. Two checks:

  (1) Consistency: does beta_k^disc converge to the continuous-time
      beta(t) as dt shrinks (holding k*dt=t fixed)? This checks the
      ALGEBRA is a genuine discretization, not an unrelated recursion
      that happens to look similar.
  (2) Empirical validity: M = sup|h''| is NOT known in closed form for
      this system (the CBF-QP filter's sensitivity du/dh varies by
      regime -- saturated vs. actively computing). We ESTIMATE M
      empirically from a held-out calibration set of real trajectories
      (numerical h'' via finite differences on the h' trace), then check
      whether h_k >= beta_k^disc holds on a SEPARATE, independently-seeded
      set of trajectories using that estimated M -- an honest
      calibrate-then-validate split, not circular.
"""
import numpy as np
import json
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.strategies import run_strategy

COMMON = dict(v_max=5.0, a_push=3.0, u_lo=-3.0, u_hi=3.0, gamma=1.5,
              delta_max=0.5, dt_cycle=0.01, T=3.0, sigma=1.0, eta=0.10,
              eps_trig=0.02, T_fixed_naive=0.8, w_drift=1.0)


def get_h_trace(theta_true, v0, n_ticks, seed):
    """Re-run bftc and extract the real h(t) trace by monkeypatching a
    trace list into a lightly modified copy of the strategy loop.
    Simplest honest approach: re-implement just enough of the loop here,
    reusing core.strategies' internals is awkward for tracing, so we
    call run_strategy per-trial (already does this) -- but run_strategy
    doesn't return the trace, so we do a local re-derivation using the
    SAME core CBF/detector modules directly for full fidelity, not a
    simplified proxy.
    """
    import numpy as np
    from core.detector import RLSFaultDetector
    from core.certificate import eps_eta_curve
    from scipy.stats import norm as _norm

    v_max, a_push = COMMON["v_max"], COMMON["a_push"]
    u_lo, u_hi = COMMON["u_lo"], COMMON["u_hi"]
    gamma, delta_max = COMMON["gamma"], COMMON["delta_max"]
    dt_cycle, T = COMMON["dt_cycle"], COMMON["T"]
    sigma, eta, eps_trig = COMMON["sigma"], COMMON["eta"], COMMON["eps_trig"]
    w_drift = COMMON["w_drift"]

    rng = np.random.default_rng(seed)
    det = RLSFaultDetector(1, forgetting=1.0, theta_init=1.0, p_init=100.0)
    z_precomp = np.sqrt(2 * np.log(2 * 1 / eta))  # sub-Gaussian Chernoff constant (m=1), corrected
    n_cycles = int(T / dt_cycle)
    v = v0
    h_hist = np.zeros(n_cycles)
    t_hist = np.zeros(n_cycles)

    for k in range(n_cycles):
        h = v_max - v
        theta_hat_point = 1.0 - det.delta_hat[0]
        if k == 0:
            eps_now = delta_max
        else:
            P_now = det.uncertainty.reshape(1, -1)
            eps_now = min(eps_eta_curve(P_now, sigma, eta, m=1,
                                         z_precomputed=z_precomp)[-1], delta_max)
        theta_hat_eff = theta_hat_point
        extra_margin = abs(-1.0) * eps_now * u_hi
        u_upper_num = gamma * h - extra_margin - w_drift
        u_upper = u_upper_num / max(theta_hat_eff, 1e-3)
        u_upper = min(u_hi, u_upper)
        u_cmd = np.clip(a_push, u_lo, u_upper) if u_upper >= u_lo else u_lo
        u_actual = theta_true * u_cmd

        for _ in range(n_ticks):
            y_obs = theta_true * u_cmd + rng.normal(0, sigma)
            det.step(np.array([u_cmd]), np.array([y_obs]), n_ticks=1)

        v = v + dt_cycle * (w_drift + u_actual)
        h_hist[k] = v_max - v
        t_hist[k] = (k + 1) * dt_cycle

    return t_hist, h_hist


def estimate_M(n_calib_trials=100, n_ticks=8, seed0=70000):
    """Estimate M = sup|h''| from a calibration set via finite differences
    on h'(t) (itself finite-differenced from h(t))."""
    rng = np.random.default_rng(seed0)
    max_hdd = 0.0
    for trial in range(n_calib_trials):
        theta_true = rng.uniform(1 - COMMON["delta_max"], 1.0)
        v0 = rng.uniform(0, COMMON["v_max"] * 0.6)
        t_hist, h_hist = get_h_trace(theta_true, v0, n_ticks, seed=seed0 + trial)
        dt = COMMON["dt_cycle"]
        hd = np.diff(h_hist) / dt          # h'(t), length n-1
        hdd = np.diff(hd) / dt              # h''(t), length n-2
        max_hdd = max(max_hdd, np.max(np.abs(hdd)))
    return max_hdd


def discrete_floor(h0, gamma, dt, rho_max, M, n_steps):
    beta = np.zeros(n_steps)
    beta_prev = h0
    for k in range(n_steps):
        beta_next = (1 - gamma * dt) * beta_prev - dt * rho_max - (dt ** 2 / 2) * M
        beta[k] = beta_next
        beta_prev = beta_next
    return beta


def continuous_floor(h0, gamma, rho_max, t_array):
    return (h0 + rho_max / gamma) * np.exp(-gamma * t_array) - rho_max / gamma


def check_consistency():
    """Check 1: does beta_k^disc -> beta(t) as dt shrinks?"""
    h0, gamma, rho_max, M = 2.0, 1.5, 1.5, 5.0  # illustrative constants
    T = 2.0
    results = {}
    for dt in [0.1, 0.02, 0.005, 0.001]:
        n_steps = int(T / dt)
        beta_disc = discrete_floor(h0, gamma, dt, rho_max, M, n_steps)
        t_array = np.arange(1, n_steps + 1) * dt
        beta_cont = continuous_floor(h0, gamma, rho_max, t_array)
        # compare at t=1.0 (a common time point across all dt)
        idx = int(round(1.0 / dt)) - 1
        diff = abs(beta_disc[idx] - beta_cont[idx])
        results[dt] = dict(beta_disc=float(beta_disc[idx]),
                            beta_cont=float(beta_cont[idx]), diff=float(diff))
        print(f"dt={dt}: beta_disc(t=1)={beta_disc[idx]:.6f} "
              f"beta_cont(t=1)={beta_cont[idx]:.6f} diff={diff:.6f}")
    return results


def check_validity(M_estimated, n_trials=150, n_ticks=8, seed0=80000):
    """Check 2: does h_k >= beta_k^disc hold out-of-sample?"""
    gamma, dt = COMMON["gamma"], COMMON["dt_cycle"]
    rho_max = 1.0 * COMMON["delta_max"] * COMMON["u_hi"]
    rng = np.random.default_rng(seed0)
    n_violations = 0
    min_gaps = []
    for trial in range(n_trials):
        theta_true = rng.uniform(1 - COMMON["delta_max"], 1.0)
        v0 = rng.uniform(0, COMMON["v_max"] * 0.6)
        t_hist, h_hist = get_h_trace(theta_true, v0, n_ticks, seed=seed0 + trial)
        h0 = COMMON["v_max"] - v0
        n_steps = len(h_hist)
        beta_disc = discrete_floor(h0, gamma, dt, rho_max, M_estimated, n_steps)
        gap = h_hist - beta_disc
        min_gap = float(gap.min())
        min_gaps.append(min_gap)
        if min_gap < -1e-9:
            n_violations += 1
    return n_violations, n_trials, min_gaps


def main():
    print("=== Check 1: consistency (discrete -> continuous as dt->0) ===")
    consistency = check_consistency()

    print("\n=== Estimating M from calibration set (100 trials) ===")
    M_est = estimate_M(n_calib_trials=100)
    print(f"estimated M = sup|h''| = {M_est:.4f}")

    print("\n=== Check 2: out-of-sample validity (150 held-out trials) ===")
    n_viol, n_trials, min_gaps = check_validity(M_est)
    print(f"violations of h_k >= beta_k^disc: {n_viol}/{n_trials}")
    print(f"min gap stats: mean={np.mean(min_gaps):.4f}, "
          f"min={np.min(min_gaps):.4f}, max={np.max(min_gaps):.4f}")

    os.makedirs("/home/claude/ftc_paper/results", exist_ok=True)
    with open("/home/claude/ftc_paper/results/e9_discrete_time_bound.json", "w") as f:
        json.dump(dict(consistency=consistency, M_estimated=float(M_est),
                        n_violations=n_viol, n_trials=n_trials,
                        min_gap_mean=float(np.mean(min_gaps)),
                        min_gap_min=float(np.min(min_gaps))), f, indent=2)
    print("\nSaved to results/e9_discrete_time_bound.json")


if __name__ == "__main__":
    main()
