"""
e2b_falsification_check.py

Sanity check on the VALIDATION METHODOLOGY itself (not on the correctly-
specified theory): if the certificate is handed a noise level that
UNDERESTIMATES the true sensor noise, eps_eta(k) will be falsely small
(overconfident), the detector will trigger too early with a bad estimate,
and the empirical violation rate should rise ABOVE eta. If it doesn't, the
e2 validation test would not actually be capable of catching a broken
theory, which would make the "0 violations" result in e2 meaningless
rather than reassuring. This script exists to make sure that isn't the
case.
"""
import numpy as np
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/..")
from core.detector import RLSFaultDetector
from core.certificate import eps_eta_curve, two_phase_floor
from scipy.stats import beta as beta_dist


def clopper_pearson(n_violations, n_trials, conf=0.95):
    lo = 0.0 if n_violations == 0 else beta_dist.ppf((1 - conf) / 2, n_violations, n_trials - n_violations + 1)
    hi = 1.0 if n_violations == n_trials else beta_dist.ppf(1 - (1 - conf) / 2, n_violations + 1, n_trials - n_violations)
    return lo, hi


def run_trial_decoupled(theta_true, v0, v_max, a_push, u_lo, u_hi, gamma,
                         delta_max, dt_cycle, T, n_ticks_per_cycle,
                         true_sigma, cert_sigma, eta, eps_trig, seed):
    rng = np.random.default_rng(seed)
    det = RLSFaultDetector(1, forgetting=1.0, theta_init=1.0, p_init=100.0)
    n_cycles = int(T / dt_cycle)
    v = v0
    h0 = v_max - v0
    t_hist = np.zeros(n_cycles)
    h_hist = np.zeros(n_cycles)
    P_hist = np.zeros((n_cycles, 1))
    triggered = False
    t_trigger = None
    rho_max = 1.0 * delta_max * u_hi

    for k in range(n_cycles):
        h = v_max - v
        theta_hat_current = det.delta_hat
        theta_hat_eff = 1.0 - theta_hat_current[0] if triggered else 1.0
        u_upper = min(u_hi, gamma * h / max(theta_hat_eff, 1e-3))
        u_cmd = np.clip(a_push, u_lo, u_upper) if u_upper >= u_lo else u_lo
        u_actual = theta_true * u_cmd

        for _ in range(n_ticks_per_cycle):
            y_obs = theta_true * u_cmd + rng.normal(0, true_sigma)   # TRUE noise
            det.step(np.array([u_cmd]), np.array([y_obs]), n_ticks=1)
        P_hist[k] = det.uncertainty

        v = v + dt_cycle * u_actual
        t_hist[k] = (k + 1) * dt_cycle
        h_hist[k] = v_max - v

        if not triggered:
            eps_k = eps_eta_curve(P_hist[:k + 1], cert_sigma, eta, m=1)[-1]  # CERT (possibly wrong) noise
            if eps_k <= eps_trig:
                triggered = True
                t_trigger = t_hist[k]

    rho_post = 1.0 * eps_trig * u_hi
    floor = two_phase_floor(t_hist, h0, t_trigger, rho_max, rho_post, gamma)
    gap = h_hist - floor
    return float(gap.min()) < -1e-6


def sweep(true_sigma, cert_sigma, label, n_trials=500):
    v_max, a_push = 5.0, 3.0
    u_lo, u_hi = -3.0, 3.0
    gamma, delta_max = 1.5, 0.9
    dt_cycle, T = 0.01, 3.0
    eta, eps_trig, n_ticks = 0.10, 0.05, 3
    rng = np.random.default_rng(7)
    n_viol = 0
    for trial in range(n_trials):
        theta_true = rng.uniform(1.0 - delta_max, 1.0)
        v0 = rng.uniform(0.0, v_max * 0.6)
        v = run_trial_decoupled(theta_true, v0, v_max, a_push, u_lo, u_hi,
                                 gamma, delta_max, dt_cycle, T, n_ticks,
                                 true_sigma, cert_sigma, eta, eps_trig,
                                 seed=1000 + trial)
        n_viol += int(v)
    lo, hi = clopper_pearson(n_viol, n_trials)
    print(f"{label}: true_sigma={true_sigma}, cert_sigma={cert_sigma} "
          f"-> violations {n_viol}/{n_trials} ({n_viol/n_trials:.3f}), "
          f"95% CI [{lo:.4f},{hi:.4f}], eta={eta}")
    return n_viol / n_trials


if __name__ == "__main__":
    print("=== Falsification check: does under-reporting noise break the guarantee? ===")
    rate_correct = sweep(0.15, 0.15, "correctly specified (baseline, matches e2)")
    rate_mild = sweep(0.15, 0.05, "cert UNDERESTIMATES noise by 3x")
    rate_severe = sweep(0.15, 0.005, "cert UNDERESTIMATES noise by 30x")
    print()
    print("Expected pattern if the theory/test is meaningful: violation rate "
          "should INCREASE as cert_sigma is made more wrong, and should "
          "exceed eta=0.10 once misspecification is severe enough.")
    print(f"correct={rate_correct:.3f}  mild-misspec={rate_mild:.3f}  "
          f"severe-misspec={rate_severe:.3f}")
