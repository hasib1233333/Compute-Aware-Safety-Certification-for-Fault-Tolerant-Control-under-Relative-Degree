"""
e3_double_integrator_comparison.py

The actual H1/H2 test on the double-integrator testbed: sweep the
per-cycle compute budget (n_ticks_per_cycle) and compare no_ftc,
passive_ftc, naive_active_ftc (fixed wall-clock trigger), and bftc
(proposed) on REAL, physical outcomes:
  - safety: true constraint violation rate (h(t) < 0 at any point),
    NOT the theoretical floor (that was already validated separately).
  - performance: mean_v_frac (how close to the nominal task the robot
    actually got), which is where passive-FTC's conservatism and
    naive-FTC's miscalibration should show up as a real, measured cost.

T_fixed_naive is calibrated (not tuned to make BFTC win) from the
BFTC-at-n_ticks=2 trigger-time distribution measured separately
(experiments/e3_calibration_check.py output): median ~0.06s.
"""
import numpy as np
import json
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.strategies import run_strategy
from scipy.stats import beta as beta_dist


def clopper_pearson(k, n, conf=0.95):
    lo = 0.0 if k == 0 else beta_dist.ppf((1 - conf) / 2, k, n - k + 1)
    hi = 1.0 if k == n else beta_dist.ppf(1 - (1 - conf) / 2, k + 1, n - k)
    return lo, hi


def main():
    v_max, a_push = 5.0, 3.0
    u_lo, u_hi = -3.0, 3.0
    gamma, delta_max = 1.5, 0.5
    dt_cycle, T = 0.01, 3.0
    sigma, eta, eps_trig = 1.0, 0.10, 0.02
    T_fixed_naive = 0.8
    w_drift = 1.0   # persistent disturbance, calibrated feasible even at worst-case fault

    budgets_env = os.environ.get("E3_BUDGETS")
    budgets = [int(x) for x in budgets_env.split(",")] if budgets_env else \
        [1, 2, 3, 5, 8, 10, 15, 25, 40]
    strategies = ["no_ftc", "passive_ftc", "naive_active_ftc", "bftc_binary", "bftc"]
    n_trials = int(os.environ.get("E3_NTRIALS", "150"))

    out_path = "/home/claude/ftc_paper/results/e3_double_integrator_comparison.json"
    all_results = {}
    if os.path.exists(out_path):
        with open(out_path) as f:
            all_results = json.load(f)
    for n_ticks in budgets:
        for strat in strategies:
            key = f"{strat}__budget_{n_ticks}"
            rng = np.random.default_rng(42)
            recs = []
            for trial in range(n_trials):
                theta_true = rng.uniform(1.0 - delta_max, 1.0)
                v0 = rng.uniform(0.0, v_max * 0.6)
                r = run_strategy(strat, theta_true, v0, v_max, a_push, u_lo,
                                  u_hi, gamma, delta_max, dt_cycle, T,
                                  n_ticks, sigma, eta, eps_trig,
                                  T_fixed_naive, seed=5000 + trial, w_drift=w_drift)
                recs.append(dict(h_min=r["h_min"], viol=r["safety_violation"],
                                  mean_v_frac=r["mean_v_frac"],
                                  t_trigger=r["t_trigger"]))
            n_viol = sum(r["viol"] for r in recs)
            lo, hi = clopper_pearson(n_viol, n_trials)
            mean_perf = float(np.mean([r["mean_v_frac"] for r in recs]))
            std_perf = float(np.std([r["mean_v_frac"] for r in recs]))
            trig_times = [r["t_trigger"] for r in recs if r["t_trigger"] is not None]
            all_results[key] = dict(
                strategy=strat, budget=n_ticks, n_trials=n_trials,
                n_violations=n_viol, violation_rate=n_viol / n_trials,
                viol_ci_lo=float(lo), viol_ci_hi=float(hi),
                mean_perf=mean_perf, std_perf=std_perf,
                mean_trigger_time=float(np.mean(trig_times)) if trig_times else None,
            )
        print(f"budget={n_ticks:3d} done: " +
              "  ".join(f"{s}: viol={all_results[f'{s}__budget_{n_ticks}']['violation_rate']:.3f} "
                         f"perf={all_results[f'{s}__budget_{n_ticks}']['mean_perf']:.3f}"
                         for s in strategies))
        os.makedirs("/home/claude/ftc_paper/results", exist_ok=True)
        with open(out_path, "w") as f:
            json.dump(all_results, f, indent=2)
    print("\nSaved to results/e3_double_integrator_comparison.json")


if __name__ == "__main__":
    main()
