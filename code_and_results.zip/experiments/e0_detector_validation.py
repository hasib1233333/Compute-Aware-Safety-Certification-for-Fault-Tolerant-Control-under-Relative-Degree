"""
e0_detector_validation.py

Sanity-checks core/detector.py in complete isolation, with SYNTHETIC data
where the true delta is known exactly (no robot dynamics involved at all).
This must pass before the detector is trusted inside any of the four
testbeds -- it is checking the estimator, not the theory yet.

Checks:
  (1) With persistent excitation and NO noise, does theta_hat -> true theta?
  (2) Is ||delta_hat_k - delta_true|| empirically non-increasing (up to
      noise) in the number of RLS ticks k, across many random trials and
      random fault vectors? This is the anytime property.
  (3) What functional form (exponential? power-law?) best fits the observed
      decay curve? -- needed to instantiate the certificate formula honestly
      rather than assuming a form.
"""
import numpy as np
import json
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.detector import RLSFaultDetector

rng = np.random.default_rng(0)


def run_single_trial(m, delta_true, n_ticks_max, noise_std, forgetting=0.995, seed=0):
    local_rng = np.random.default_rng(seed)
    det = RLSFaultDetector(m, forgetting=forgetting, theta_init=1.0, p_init=100.0)
    theta_true = 1.0 - np.asarray(delta_true)
    errs = np.zeros(n_ticks_max)
    for k in range(n_ticks_max):
        u_cmd = local_rng.uniform(-1.0, 1.0, size=m)   # persistent excitation
        y_true = theta_true * u_cmd
        y_obs = y_true + local_rng.normal(0, noise_std, size=m)
        det.step(u_cmd, y_obs, n_ticks=1)
        errs[k] = np.linalg.norm(det.delta_hat - np.asarray(delta_true))
    return errs


def main():
    m = 4
    n_ticks_max = 400
    n_trials = 60
    noise_std = 0.02
    results = {}

    # --- Check 1: noiseless convergence to exact truth ---
    delta_true = np.array([0.0, 0.3, 0.6, 0.85])
    errs_noiseless = run_single_trial(m, delta_true, n_ticks_max, noise_std=0.0, seed=1)
    final_err_noiseless = errs_noiseless[-1]
    print(f"[Check 1] noiseless final ||delta_hat-delta|| = {final_err_noiseless:.6f} "
          f"(expect ~0)")

    # --- Check 2: anytime monotonicity across many random trials/faults ---
    all_curves = np.zeros((n_trials, n_ticks_max))
    violations = 0
    violation_magnitudes = []
    for t in range(n_trials):
        d_true = rng.uniform(0.0, 0.9, size=m)
        curve = run_single_trial(m, d_true, n_ticks_max, noise_std, forgetting=0.995, seed=100 + t)
        all_curves[t] = curve
        # check monotonic non-increase on a SMOOTHED version (raw RLS with
        # noise will have local upticks; the theory requires the envelope /
        # expected trend to be non-increasing, which is what we actually test)
        window = 20
        smoothed = np.convolve(curve, np.ones(window) / window, mode='valid')
        diffs = np.diff(smoothed)
        bad = diffs[diffs > 1e-4]
        if len(bad) > 0:
            violations += 1
            violation_magnitudes.append(float(bad.max()))

    mean_curve = all_curves.mean(axis=0)
    std_curve = all_curves.std(axis=0)

    print(f"[Check 2] {violations}/{n_trials} trials showed a smoothed-envelope "
          f"increase >1e-4 at some point")
    if violation_magnitudes:
        print(f"          max violation magnitude across those trials: "
              f"{max(violation_magnitudes):.5f}")

    # --- Check 3: fit functional form of the decay envelope ---
    k = np.arange(1, n_ticks_max + 1)
    # avoid fitting the flat noise floor at the end; fit early/mid region
    fit_region = slice(0, 150)
    log_mean = np.log(np.maximum(mean_curve[fit_region], 1e-6))
    # exponential fit: log(err) = log(a) - b*k
    A_exp = np.vstack([np.ones_like(k[fit_region], dtype=float), -k[fit_region]]).T
    coef_exp, *_ = np.linalg.lstsq(A_exp, log_mean, rcond=None)
    a_exp, b_exp = np.exp(coef_exp[0]), coef_exp[1]
    pred_exp = a_exp * np.exp(-b_exp * k)
    resid_exp = np.sum((mean_curve[fit_region] - pred_exp[fit_region]) ** 2)

    # power-law fit: log(err) = log(a) - b*log(k)
    log_k = np.log(k[fit_region].astype(float))
    A_pow = np.vstack([np.ones_like(log_k), -log_k]).T
    coef_pow, *_ = np.linalg.lstsq(A_pow, log_mean, rcond=None)
    a_pow, b_pow = np.exp(coef_pow[0]), coef_pow[1]
    pred_pow = a_pow * np.power(k.astype(float), -b_pow)
    resid_pow = np.sum((mean_curve[fit_region] - pred_pow[fit_region]) ** 2)

    print(f"[Check 3] exponential fit: eps(k) ~ {a_exp:.4f} * exp(-{b_exp:.4f} k), "
          f"SSE={resid_exp:.5f}")
    print(f"          power-law  fit: eps(k) ~ {a_pow:.4f} * k^-{b_pow:.4f}, "
          f"SSE={resid_pow:.5f}")
    best = "exponential" if resid_exp < resid_pow else "power-law"
    print(f"          best fit on this synthetic data: {best}")

    results = dict(
        final_err_noiseless=float(final_err_noiseless),
        n_trials=n_trials,
        n_violations=violations,
        max_violation_magnitude=float(max(violation_magnitudes)) if violation_magnitudes else 0.0,
        mean_curve=mean_curve.tolist(),
        std_curve=std_curve.tolist(),
        exp_fit=dict(a=float(a_exp), b=float(b_exp), sse=float(resid_exp)),
        pow_fit=dict(a=float(a_pow), b=float(b_pow), sse=float(resid_pow)),
        best_fit=best,
    )
    os.makedirs("/home/claude/ftc_paper/results", exist_ok=True)
    with open("/home/claude/ftc_paper/results/e0_detector_validation.json", "w") as f:
        json.dump(results, f, indent=2)
    print("\nSaved to results/e0_detector_validation.json")


if __name__ == "__main__":
    main()
