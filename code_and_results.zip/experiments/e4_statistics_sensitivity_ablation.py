"""
e4_statistics_sensitivity_ablation.py

Addresses reviewer-feedback gaps with REAL new experiments (not
re-analysis of already-aggregated data, which lacks per-trial pairing):

  (A) Paired per-trial results at two representative budgets (low=1,
      high=25), same random seeds across all 5 strategies, enabling
      McNemar's test on violation outcomes and paired effect size on
      performance.
  (B) Fault-severity sensitivity: sweep delta_max in {0.3,0.5,0.7,0.85}
      at fixed budget=8, all strategies.
  (C) Noise-level sensitivity: sweep sigma in {0.3,0.5,1.0,2.0} at fixed
      budget=8, all strategies.
  (D) Bonferroni-correction ablation: BFTC with vs without the
      Bonferroni factor (m=1 here so this is really "conservative
      z=norm.ppf(1-eta/2)" vs "uncorrected-style z=norm.ppf(1-eta)",
      the m=1 case still differs by the factor of 2 in the tail
      probability budget -- a real, checkable ablation even though
      m=1 for this single-actuator testbed).
  (E) Computational cost: real wall-clock and per-tick timing for the
      detector, measured directly, not estimated.

All on the double-integrator testbed (the only fully validated one),
using the SAME core/strategies.py code as e3 -- no reimplementation, so
results are directly comparable to Table 1 in the manuscript.
"""
import numpy as np
import json
import time
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.strategies import run_strategy
from core.detector import RLSFaultDetector
from scipy.stats import beta as beta_dist, norm

COMMON = dict(v_max=5.0, a_push=3.0, u_lo=-3.0, u_hi=3.0, gamma=1.5,
              delta_max=0.5, dt_cycle=0.01, T=3.0, sigma=1.0, eta=0.10,
              eps_trig=0.02, T_fixed_naive=0.8, w_drift=1.0)

STRATS = ["no_ftc", "passive_ftc", "naive_active_ftc", "bftc_binary", "bftc"]


def run_paired(n_trials, n_ticks, seed0=20000):
    """(A) Per-trial paired results across all strategies, same seeds."""
    rng = np.random.default_rng(seed0)
    theta_trues = rng.uniform(1.0 - COMMON["delta_max"], 1.0, size=n_trials)
    v0s = rng.uniform(0.0, COMMON["v_max"] * 0.6, size=n_trials)
    out = {s: [] for s in STRATS}
    for i in range(n_trials):
        for s in STRATS:
            r = run_strategy(s, theta_trues[i], v0s[i], n_ticks_per_cycle=n_ticks,
                              seed=seed0 + 1000 + i, **COMMON)
            out[s].append(dict(violated=r["safety_violation"],
                                perf=r["mean_v_frac"]))
    return out


def mcnemar_test(viol_a, viol_b):
    """McNemar's test on paired binary outcomes (violation yes/no)."""
    viol_a = np.array(viol_a, dtype=bool)
    viol_b = np.array(viol_b, dtype=bool)
    n01 = int(np.sum((~viol_a) & viol_b))   # a safe, b violated
    n10 = int(np.sum(viol_a & (~viol_b)))   # a violated, b safe
    n = n01 + n10
    if n == 0:
        return dict(n01=n01, n10=n10, statistic=0.0, p_value=1.0)
    # exact binomial two-sided test (small-n safe; standard for McNemar with small discordant counts)
    from scipy.stats import binomtest
    res = binomtest(min(n01, n10), n, 0.5, alternative="two-sided")
    return dict(n01=n01, n10=n10, statistic=float(min(n01, n10)), p_value=float(res.pvalue))


def paired_effect_size(perf_a, perf_b):
    """Cohen's d_z for paired performance differences."""
    diff = np.array(perf_a) - np.array(perf_b)
    if diff.std(ddof=1) == 0:
        return 0.0
    return float(diff.mean() / diff.std(ddof=1))


def sensitivity_sweep(param_name, values, n_trials=100, n_ticks=8, seed0=30000):
    results = {}
    for val in values:
        cfg = dict(COMMON)
        cfg[param_name] = val
        rng = np.random.default_rng(seed0 + int(val * 1000))
        for s in STRATS:
            n_viol = 0
            perfs = []
            for i in range(n_trials):
                theta_true = rng.uniform(1.0 - cfg["delta_max"], 1.0)
                v0 = rng.uniform(0.0, cfg["v_max"] * 0.6)
                r = run_strategy(s, theta_true, v0, n_ticks_per_cycle=n_ticks,
                                  seed=seed0 + i, **cfg)
                n_viol += r["safety_violation"]
                perfs.append(r["mean_v_frac"])
            results[f"{param_name}_{val}__{s}"] = dict(
                violation_rate=n_viol / n_trials, mean_perf=float(np.mean(perfs)))
    return results


def bonferroni_ablation(n_trials=150, n_ticks=8, seed0=40000):
    """(D) BFTC with proper Bonferroni (m=1: z=norm.ppf(1-eta/2)) vs a
    naively uncorrected version (z=norm.ppf(1-eta)) -- for m=1 actuator
    this is not the multi-actuator Bonferroni factor itself, but the
    same *style* of correction choice, and IS the exact computation our
    code performs; we ablate it honestly rather than pretend a m>1
    multi-actuator ablation we have not run.
    """
    out = {"with_correction": [], "without_correction": []}
    rng = np.random.default_rng(seed0)
    theta_trues = rng.uniform(1.0 - COMMON["delta_max"], 1.0, size=n_trials)
    v0s = rng.uniform(0.0, COMMON["v_max"] * 0.6, size=n_trials)

    for i in range(n_trials):
        r_corrected = run_strategy("bftc", theta_trues[i], v0s[i],
                                    n_ticks_per_cycle=n_ticks,
                                    seed=seed0 + 1000 + i, **COMMON)
        out["with_correction"].append(dict(violated=r_corrected["safety_violation"],
                                            perf=r_corrected["mean_v_frac"]))

    # uncorrected variant: monkeypatch eta to 2*eta so z=norm.ppf(1-eta) effectively
    cfg_uncorrected = dict(COMMON)
    cfg_uncorrected["eta"] = min(COMMON["eta"] * 2, 0.999)
    for i in range(n_trials):
        r_uncorrected = run_strategy("bftc", theta_trues[i], v0s[i],
                                      n_ticks_per_cycle=n_ticks,
                                      seed=seed0 + 1000 + i, **cfg_uncorrected)
        out["without_correction"].append(dict(violated=r_uncorrected["safety_violation"],
                                               perf=r_uncorrected["mean_v_frac"]))
    return out


def computational_cost(n_reps=50):
    """(E) Real measured wall-clock cost of one RLS tick, and of a full
    control-cycle decision for bftc at a few budgets, on THIS machine.
    Reported as machine-relative (not absolute FLOPS), consistent with
    reproducibility norms -- exact hardware stated in the manuscript.
    """
    det = RLSFaultDetector(1, forgetting=1.0, theta_init=1.0, p_init=100.0)
    rng = np.random.default_rng(1)
    t0 = time.perf_counter()
    for _ in range(n_reps * 1000):
        u_cmd = rng.uniform(-3, 3)
        y_obs = 0.5 * u_cmd + rng.normal(0, 1.0)
        det.step(np.array([u_cmd]), np.array([y_obs]), n_ticks=1)
    t1 = time.perf_counter()
    per_tick_us = (t1 - t0) / (n_reps * 1000) * 1e6

    budget_costs = {}
    for n_ticks in [1, 5, 10, 25, 40]:
        t0 = time.perf_counter()
        for _ in range(n_reps):
            run_strategy("bftc", 0.5, 2.0, n_ticks_per_cycle=n_ticks, seed=1, **COMMON)
        t1 = time.perf_counter()
        budget_costs[n_ticks] = (t1 - t0) / n_reps

    return dict(per_tick_microseconds=per_tick_us, per_trial_seconds_by_budget=budget_costs)


def main():
    section = os.environ.get("E4_SECTION", "all")
    out_path = "/home/claude/ftc_paper/results/e4_statistics_sensitivity_ablation.json"
    saved = {}
    if os.path.exists(out_path):
        with open(out_path) as f:
            saved = json.load(f)

    if section in ("A_low", "all"):
        print("=== (A) Paired per-trial comparison, low budget (n_ticks=1) ===")
        saved["paired_low_budget_1"] = run_paired(n_trials=150, n_ticks=1)
        with open(out_path, "w") as f:
            json.dump(saved, f, indent=2)
        print("  saved A_low")

    if section in ("A_high", "all"):
        print("=== (A) Paired per-trial comparison, high budget (n_ticks=25) ===")
        saved["paired_high_budget_25"] = run_paired(n_trials=150, n_ticks=25)
        with open(out_path, "w") as f:
            json.dump(saved, f, indent=2)
        print("  saved A_high")

    if section in ("stats", "all"):
        stats = {}
        for label, key in [("low_budget_1", "paired_low_budget_1"),
                            ("high_budget_25", "paired_high_budget_25")]:
            if key not in saved:
                continue
            paired = saved[key]
            stats[label] = {}
            for s in STRATS:
                if s == "bftc":
                    continue
                mc = mcnemar_test([r["violated"] for r in paired["bftc"]],
                                   [r["violated"] for r in paired[s]])
                es = paired_effect_size([r["perf"] for r in paired["bftc"]],
                                         [r["perf"] for r in paired[s]])
                stats[label][f"bftc_vs_{s}"] = dict(mcnemar=mc, cohens_dz=es)
            print(f"  [{label}] stats computed")
        saved["paired_statistics"] = stats
        with open(out_path, "w") as f:
            json.dump(saved, f, indent=2)

    if section in ("B", "all"):
        print("=== (B) Fault-severity sensitivity ===")
        saved["sensitivity_fault_severity"] = sensitivity_sweep("delta_max", [0.3, 0.5, 0.7, 0.85])
        with open(out_path, "w") as f:
            json.dump(saved, f, indent=2)
        print("  saved B")

    if section in ("C", "all"):
        print("=== (C) Noise sensitivity ===")
        saved["sensitivity_noise"] = sensitivity_sweep("sigma", [0.3, 0.5, 1.0, 2.0])
        with open(out_path, "w") as f:
            json.dump(saved, f, indent=2)
        print("  saved C")

    if section in ("D", "all"):
        print("=== (D) Bonferroni ablation ===")
        bonf = bonferroni_ablation()
        n = len(bonf["with_correction"])
        viol_with = sum(r["violated"] for r in bonf["with_correction"])
        viol_without = sum(r["violated"] for r in bonf["without_correction"])
        print(f"  with correction: {viol_with}/{n} violations")
        print(f"  without correction: {viol_without}/{n} violations")
        saved["bonferroni_ablation"] = dict(
            n_trials=n, viol_with=viol_with, viol_without=viol_without,
            with_correction=bonf["with_correction"],
            without_correction=bonf["without_correction"])
        with open(out_path, "w") as f:
            json.dump(saved, f, indent=2)

    if section in ("E", "all"):
        print("=== (E) Computational cost ===")
        cost = computational_cost()
        print(f"  per RLS tick: {cost['per_tick_microseconds']:.2f} microseconds")
        print(f"  per-trial cost by budget: {cost['per_trial_seconds_by_budget']}")
        saved["computational_cost"] = cost
        with open(out_path, "w") as f:
            json.dump(saved, f, indent=2)

    print("\nSaved to", out_path)


if __name__ == "__main__":
    main()
