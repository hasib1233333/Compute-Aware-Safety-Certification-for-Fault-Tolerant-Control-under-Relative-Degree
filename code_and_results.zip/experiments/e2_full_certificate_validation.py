"""
e2_full_certificate_validation.py

Combines core/detector.py (real, noisy RLS) with core/certificate.py
(eps_eta, two-phase floor) on the same double-integrator system as e1, now
WITH detection and reconfiguration active. This is the actual end-to-end
test of the full BFTC certificate claim from theory.md.

Anytime-compute model used here (see reasoning in code comments): per
control cycle (dt_cycle), u_cmd is held fixed (zero-order hold, standard).
n_ticks_per_cycle independent noisy samples of y = theta_true*u_cmd + noise
are available to the detector; n_ticks_per_cycle is what tau_budget buys
(more compute -> can acquire/process more independent fault-relevant
samples per unit wall-clock time, e.g. from a faster-than-control-rate IMU
sub-loop). This is a modeling CHOICE, stated explicitly, not something
claimed to be the only possible anytime-compute abstraction -- it is the
one the theory and detector implementation are built around.

Claim under test: with confidence budget eta, the observed h(t) should
stay above the two-phase floor for at least (1-eta) fraction of trials.
We run n_trials, count violations, and report a Clopper-Pearson exact
confidence interval on the true violation rate to see if it's consistent
with the eta we asked for -- NOT just eyeballing a raw fraction.
"""
import numpy as np
import json
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.detector import RLSFaultDetector
from core.certificate import eps_eta_curve, trigger_tick, two_phase_floor
from scipy.stats import beta as beta_dist


def clopper_pearson(n_violations, n_trials, conf=0.95):
    lo = 0.0 if n_violations == 0 else beta_dist.ppf((1 - conf) / 2, n_violations, n_trials - n_violations + 1)
    hi = 1.0 if n_violations == n_trials else beta_dist.ppf(1 - (1 - conf) / 2, n_violations + 1, n_trials - n_violations)
    return lo, hi


def run_trial(theta_true, v0, v_max, a_push, u_lo, u_hi, gamma, delta_max,
              dt_cycle, T, n_ticks_per_cycle, sigma, eta, eps_trig, seed):
    rng = np.random.default_rng(seed)
    det = RLSFaultDetector(1, forgetting=1.0, theta_init=1.0, p_init=100.0)
    n_cycles = int(T / dt_cycle)
    v = v0
    h0 = v_max - v0
    t_hist = np.zeros(n_cycles)
    h_hist = np.zeros(n_cycles)
    P_hist = np.zeros((n_cycles, 1))
    triggered = False
    t_trigger = None
    theta_hat_at_trigger = None
    rho_max = 1.0 * delta_max * u_hi

    for k in range(n_cycles):
        h = v_max - v
        theta_hat_current = det.delta_hat  # note: detector tracks delta_hat = 1-theta
        theta_hat_eff = 1.0 - theta_hat_current[0] if triggered else 1.0
        # controller: pre-trigger assumes healthy (theta_hat_eff=1); this is
        # the conservative/typical choice matching Sec 4 (uncompensated
        # worst case) -- an alternative "provisional compensation" variant
        # is left as a stated design choice for future ablation, not
        # claimed to be strictly better here.
        u_upper = min(u_hi, gamma * h / max(theta_hat_eff, 1e-3))
        u_cmd = np.clip(a_push, u_lo, u_upper) if u_upper >= u_lo else u_lo
        u_actual = theta_true * u_cmd

        # detector gets n_ticks_per_cycle FRESH noisy samples this cycle
        for _ in range(n_ticks_per_cycle):
            y_obs = theta_true * u_cmd + rng.normal(0, sigma)
            det.step(np.array([u_cmd]), np.array([y_obs]), n_ticks=1)
        P_hist[k] = det.uncertainty

        v = v + dt_cycle * u_actual
        t_hist[k] = (k + 1) * dt_cycle
        h_hist[k] = v_max - v

        if not triggered:
            eps_k = eps_eta_curve(P_hist[:k + 1], sigma, eta, m=1)[-1]
            if eps_k <= eps_trig:
                triggered = True
                t_trigger = t_hist[k]
                theta_hat_at_trigger = 1.0 - det.delta_hat[0]

    eps_full = eps_eta_curve(P_hist, sigma, eta, m=1)
    rho_post = 1.0 * eps_trig * u_hi
    floor = two_phase_floor(t_hist, h0, t_trigger, rho_max, rho_post, gamma)
    gap = h_hist - floor
    min_gap = float(gap.min())
    violated = min_gap < -1e-6
    true_est_err_at_trigger = (abs(theta_hat_at_trigger - theta_true)
                                if theta_hat_at_trigger is not None else None)
    trig_est_ok = (true_est_err_at_trigger <= eps_trig) if true_est_err_at_trigger is not None else None
    return dict(min_gap=min_gap, violated=bool(violated),
                t_trigger=float(t_trigger) if t_trigger is not None else None,
                theta_true=float(theta_true),
                theta_hat_at_trigger=float(theta_hat_at_trigger) if theta_hat_at_trigger is not None else None,
                trig_est_within_eps=bool(trig_est_ok) if trig_est_ok is not None else None)


def main():
    v_max, a_push = 5.0, 3.0
    u_lo, u_hi = -3.0, 3.0
    gamma = 1.5
    delta_max = 0.9
    dt_cycle = 0.01
    T = 3.0
    sigma = 0.15
    eta = 0.10
    eps_trig = 0.05
    n_ticks_per_cycle = 3

    rng = np.random.default_rng(7)
    n_trials = 500
    results = []
    for trial in range(n_trials):
        theta_true = rng.uniform(1.0 - delta_max, 1.0)
        v0 = rng.uniform(0.0, v_max * 0.6)
        res = run_trial(theta_true, v0, v_max, a_push, u_lo, u_hi, gamma,
                         delta_max, dt_cycle, T, n_ticks_per_cycle, sigma,
                         eta, eps_trig, seed=1000 + trial)
        results.append(res)

    n_violations = sum(r["violated"] for r in results)
    n_never_triggered = sum(r["t_trigger"] is None for r in results)
    trig_ok = [r["trig_est_within_eps"] for r in results if r["trig_est_within_eps"] is not None]
    frac_trig_ok = np.mean(trig_ok) if trig_ok else float("nan")

    lo, hi = clopper_pearson(n_violations, n_trials)
    emp_rate = n_violations / n_trials

    print(f"n_trials={n_trials}, requested eta={eta}")
    print(f"floor violations: {n_violations}  (empirical rate={emp_rate:.4f})")
    print(f"95% Clopper-Pearson CI on true violation rate: [{lo:.4f}, {hi:.4f}]")
    print(f"Theory claims violation rate <= eta={eta}. "
          f"{'CONSISTENT' if hi <= eta * 1.5 else 'CHECK NEEDED'} "
          f"(upper CI {'<=' if hi<=eta else '>'} eta*1.5 tolerance band)")
    print(f"trials that never triggered within T={T}s: {n_never_triggered}/{n_trials}")
    print(f"fraction of TRIGGERED trials where true |theta_hat-theta_true| "
          f"<= eps_trig at trigger time: {frac_trig_ok:.4f} "
          f"(theory predicts >= {1-eta:.2f})")

    os.makedirs("/home/claude/ftc_paper/results", exist_ok=True)
    with open("/home/claude/ftc_paper/results/e2_full_certificate_validation.json", "w") as f:
        json.dump(dict(n_trials=n_trials, eta=eta, n_violations=n_violations,
                        emp_rate=emp_rate, ci_lo=float(lo), ci_hi=float(hi),
                        n_never_triggered=n_never_triggered,
                        frac_trig_ok=float(frac_trig_ok) if trig_ok else None,
                        params=dict(v_max=v_max, a_push=a_push, u_lo=u_lo, u_hi=u_hi,
                                    gamma=gamma, delta_max=delta_max, dt_cycle=dt_cycle,
                                    T=T, sigma=sigma, eps_trig=eps_trig,
                                    n_ticks_per_cycle=n_ticks_per_cycle),
                        results=results),
                  f, indent=2)
    print("\nSaved to results/e2_full_certificate_validation.json")


if __name__ == "__main__":
    main()
