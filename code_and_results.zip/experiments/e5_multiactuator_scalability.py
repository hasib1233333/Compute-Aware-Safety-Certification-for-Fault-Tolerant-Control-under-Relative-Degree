"""
e5_multiactuator_scalability.py

Empirically validates Prop. 5 (notes/theory.md): as the number of
independently-faultable actuators m grows (holding TOTAL actuation
capacity and total drift constant -- i.e. the same vehicle, actuation
split across more, smaller/more numerous thrusters, a standard
redundancy-vs-diagnosability tradeoff), the Bonferroni-corrected
confidence radius requires a stricter per-actuator bound, so detection
time should be non-decreasing in m. This is checked directly, not just
asserted.

System: state [p, v], m actuators, vdot = w_drift + sum_i theta_i * u_i,
h = v_max - v (same safety property as the validated single-actuator
double integrator, Sec 5, now with m-way split actuation). Each actuator
independently faulty, theta_i ~ Unif(1-delta_max, 1) iid. Per-actuator
box limits [-u_hi_total/m, u_hi_total/m] so total capacity is constant
across m (a fair comparison -- NOT giving more actuators more total
authority, isolating the diagnosability effect Prop 5 is about).

Strategies compared: no_ftc, passive_ftc, bftc (naive/binary omitted here
-- already characterized at m=1 in Sec 5; this experiment's purpose is
the m-scaling question, not re-litigating the strategy comparison).
"""
import numpy as np
import json
import time
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.detector import RLSFaultDetector
from core.certificate import eps_eta_curve
from core.multiactuator_filter import solve_multiactuator_upper
from scipy.stats import norm as _norm


def run_trial(strategy, m, theta_trues, v0, v_max, a_push_total, u_lo_total,
              u_hi_total, gamma, delta_max, dt_cycle, T, sigma, eta,
              eps_trig, n_ticks_per_cycle, w_drift, seed):
    rng = np.random.default_rng(seed)
    det = RLSFaultDetector(m, forgetting=1.0, theta_init=1.0, p_init=100.0)
    z_precomp = np.sqrt(2 * np.log(2 * m / eta))  # sub-Gaussian Chernoff constant, corrected
    n_cycles = int(T / dt_cycle)
    v = v0
    lo = np.full(m, u_lo_total / m)
    hi = np.full(m, u_hi_total / m)
    u_des = np.full(m, a_push_total / m)
    rho_max = 1.0 * delta_max * u_hi_total  # |Lg_h|=1 per unit total force

    h_hist = np.zeros(n_cycles)
    v_hist = np.zeros(n_cycles)
    t_trigger = None
    triggered = False

    for k in range(n_cycles):
        h = v_max - v
        t_now = (k + 1) * dt_cycle

        if strategy == "no_ftc":
            c = np.ones(m)
            margin = 0.0
        elif strategy == "passive_ftc":
            c = np.ones(m)
            margin = rho_max
        elif strategy == "bftc":
            theta_hat = 1.0 - det.delta_hat
            if k == 0:
                eps_now = delta_max
            else:
                P_now = det.uncertainty.reshape(1, -1)
                eps_now = min(eps_eta_curve(P_now, sigma, eta, m=m,
                                             z_precomputed=z_precomp)[-1], delta_max)
            c = np.clip(theta_hat, 1e-3, 1.0)
            margin = eps_now * u_hi_total

        b_upper = gamma * h - margin - w_drift  # want sum(theta_i*u_i) <= b_upper
        u_cmd = solve_multiactuator_upper(u_des, c, b_upper, lo, hi)
        u_actual = theta_trues * u_cmd

        if strategy == "bftc":
            for _ in range(n_ticks_per_cycle):
                y_obs = theta_trues * u_cmd + rng.normal(0, sigma, size=m)
                det.step(u_cmd, y_obs, n_ticks=1)
            if not triggered:
                P_now = det.uncertainty.reshape(1, -1)
                eps_k = eps_eta_curve(P_now, sigma, eta, m=m, z_precomputed=z_precomp)[-1]
                if eps_k <= eps_trig:
                    triggered, t_trigger = True, t_now

        v = v + dt_cycle * (w_drift + float(np.sum(u_actual)))
        h_hist[k] = v_max - v
        v_hist[k] = v

    h_min = float(h_hist.min())
    return dict(h_min=h_min, safety_violation=bool(h_min < 0),
                mean_v_frac=float(np.mean(v_hist) / v_max),
                t_trigger=float(t_trigger) if t_trigger is not None else None)


def main():
    v_max, a_push_total = 5.0, 3.0
    u_lo_total, u_hi_total = -3.0, 3.0
    gamma, delta_max = 1.5, 0.5
    dt_cycle, T = 0.01, 3.0
    sigma, eta, eps_trig = 1.0, 0.10, 0.02
    w_drift = 1.0
    n_ticks_per_cycle = 8

    m_values = [1, 4, 8, 16]
    strategies = ["no_ftc", "passive_ftc", "bftc"]
    n_trials = int(os.environ.get("E5_NTRIALS", "60"))

    out_path = "/home/claude/ftc_paper/results/e5_multiactuator_scalability.json"
    results = {}
    if os.path.exists(out_path):
        with open(out_path) as f:
            results = json.load(f)

    m_todo = os.environ.get("E5_M")
    m_list = [int(m_todo)] if m_todo else m_values

    for m in m_list:
        for strat in strategies:
            rng = np.random.default_rng(6000 + m)
            recs = []
            t0 = time.perf_counter()
            for trial in range(n_trials):
                theta_trues = rng.uniform(1.0 - delta_max, 1.0, size=m)
                v0 = rng.uniform(0.0, v_max * 0.6)
                r = run_trial(strat, m, theta_trues, v0, v_max, a_push_total,
                               u_lo_total, u_hi_total, gamma, delta_max,
                               dt_cycle, T, sigma, eta, eps_trig,
                               n_ticks_per_cycle, w_drift, seed=6000 + m * 100 + trial)
                recs.append(r)
            elapsed = time.perf_counter() - t0
            n_viol = sum(r["safety_violation"] for r in recs)
            trig_times = [r["t_trigger"] for r in recs if r["t_trigger"] is not None]
            key = f"m_{m}__{strat}"
            results[key] = dict(
                m=m, strategy=strat, n_trials=n_trials,
                violation_rate=n_viol / n_trials,
                mean_perf=float(np.mean([r["mean_v_frac"] for r in recs])),
                mean_trigger_time=float(np.mean(trig_times)) if trig_times else None,
                frac_triggered=len(trig_times) / n_trials,
                wall_clock_seconds=elapsed,
                wall_clock_per_trial_ms=elapsed / n_trials * 1000,
            )
            print(f"m={m:2d} {strat:12s}: viol={n_viol}/{n_trials} "
                  f"perf={results[key]['mean_perf']:.3f} "
                  f"trig_t={results[key]['mean_trigger_time']} "
                  f"({elapsed/n_trials*1000:.2f} ms/trial)")
        with open(out_path, "w") as f:
            json.dump(results, f, indent=2)

    print("\nSaved to", out_path)


if __name__ == "__main__":
    main()
